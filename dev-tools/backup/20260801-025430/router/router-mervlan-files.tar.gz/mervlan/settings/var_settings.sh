# ============================================================================ #
#                                                                              #
#   /$$      /$$                     /$$    /$$ /$$        /$$$$$$  /$$   /$$  #
#  | $$$    /$$$                    | $$   | $$| $$       /$$__  $$| $$$ | $$  #
#  | $$$$  /$$$$  /$$$$$$   /$$$$$$ | $$   | $$| $$      | $$  \ $$| $$$$| $$  #
#  | $$ $$/$$ $$ /$$__  $$ /$$__  $$|  $$ / $$/| $$      | $$$$$$$$| $$ $$ $$  #
#  | $$  $$$| $$| $$$$$$$$| $$  \__/ \  $$ $$/ | $$      | $$__  $$| $$  $$$$  #
#  | $$\  $ | $$| $$_____/| $$        \  $$$/  | $$      | $$  | $$| $$\  $$$  #
#  | $$ \/  | $$|  $$$$$$$| $$         \  $/   | $$$$$$$$| $$  | $$| $$ \  $$  #
#  |__/     |__/ \_______/|__/          \_/    |________/|__/  |__/|__/  \__/  #
#                                                                              #
# ============================================================================ #
#              - File: var_settings.sh || version="0.72.0"                  #
# ============================================================================ #
# - Purpose:    Define folder paths and environment variables used             #
#               throughout the MerVLAN addon.                                  #
# ============================================================================ #
[ -n "${VAR_SETTINGS_LOADED:-}" ] && return 0 2>/dev/null
# Only set if not already set (allows override for testing)
: "${MERV_BASE:?MERV_BASE must be set before sourcing folder_settings.sh}"

# Durable security/action state.  These roots deliberately live outside the
# versioned release tree and outside the browser-facing public symlink.  Test
# harnesses may override them with a path beneath their private self-test
# directory; the consuming libraries validate that boundary before writing.
: "${MERV_STATE_ROOT:=/jffs/addons/mervlan_state}"
: "${MERV_SSH_TRUST_ROOT:=$MERV_STATE_ROOT/ssh_trust}"
: "${MERV_SSH_TRUST_FILE:=$MERV_SSH_TRUST_ROOT/known_hosts.v1}"
: "${MERV_SSH_TRUST_PENDING_ROOT:=$MERV_SSH_TRUST_ROOT/pending}"
: "${MERV_SSH_TRUST_REQUESTS_ROOT:=$MERV_SSH_TRUST_ROOT/requests}"
: "${MERV_SSH_TRUST_STAGING_ROOT:=$MERV_SSH_TRUST_ROOT/staging}"
: "${MERV_SSH_TRUST_QUARANTINE_ROOT:=$MERV_SSH_TRUST_ROOT/quarantine}"
: "${MERV_SSH_TRUST_LOCK_PATH:=$MERV_SSH_TRUST_ROOT/state.lock}"
: "${MERV_UPDATE_CONSUMED_FILE:=$MERV_STATE_ROOT/update_refs.consumed}"

# ---- merv: portable `command -v` replacement ----
# merv_has <name> : true if <name> exists as function/builtin/external
# merv_cmd <name> : prints PATH-resolved executable (external only); fails if not found
if ! type merv_has >/dev/null 2>&1; then
  merv_has() { type "$1" >/dev/null 2>&1; }
  merv_cmd() {
    _merv_c="$1"
    case "$_merv_c" in
      */*) [ -x "$_merv_c" ] && { printf '%s\n' "$_merv_c"; return 0; } ;;
    esac
    _merv_oldIFS="$IFS"; IFS=:
    for _merv_d in $PATH; do
      [ -z "$_merv_d" ] && _merv_d="."
      [ -x "$_merv_d/$_merv_c" ] && { IFS="$_merv_oldIFS"; printf '%s\n' "$_merv_d/$_merv_c"; return 0; }
    done
    IFS="$_merv_oldIFS"
    return 1
  }
fi
# ---- end shim ----

# Folders
readonly SCRIPTS_DIR="/jffs/scripts"
readonly TMPDIR="/tmp/mervlan_tmp"
readonly LOGDIR="$TMPDIR/logs"
readonly FUNCDIR="$MERV_BASE/functions"
readonly SETTINGSDIR="$MERV_BASE/settings"
readonly FLAGDIR="$MERV_BASE/flags"
readonly PUBLIC_MERV_BASE="/www/user/mervlan"
readonly PUBLIC_SETTINGS_DIR="${PUBLIC_MERV_BASE}/settings"
readonly PUBLIC_SETTINGS_FILE="${PUBLIC_SETTINGS_DIR}/settings.json"
readonly LOCKDIR="$TMPDIR/locks"
readonly RESULTDIR="$TMPDIR/results"
readonly CHANGES="$TMPDIR/results/vlan_changes"
readonly COLLECTDIR="$TMPDIR/client_collection"

# ============================================================================
# MERV_MAC — per-client L2 secondary shield
# ============================================================================
: "${MERV_MAC_CHAIN:=MERV_MAC}"
: "${MERV_MAC_DB_ACTIVE:=$TMPDIR/mac_shield.db}"
: "${MERV_MAC_DB_JFFS:=$MERV_BASE/tmp/mac_shield.db}"
: "${MERV_MAC_MAX_AGE_SEC:=$((48 * 3600))}"
: "${MAC_SHIELD_VERBOSE:=0}"  # 0 = silent on stable ticks; 1 = log every tick
# Cross-node MAC shield sync. When 1 (default) the main collects client MACs
# from every configured node during each snapshot, merges them into one db, and
# pushes the merged db back to the nodes so a device known to ANY unit is
# blocked on br0 across the whole mesh. Set 0 to keep each unit's shield local
# (e.g. when SSH keys are not installed or isolated per-node dbs are desired).
: "${MERV_MAC_NODE_SYNC:=1}"

# Override DB: suppresses the MERV_MAC DROP rule for listed MACs.
# Applies cluster-wide: pushed to nodes wherever the MAC shield DB is enforced.
# MACs remain in mac_shield.db; removing an override re-locks on next reload.
: "${MERV_MAC_OVERRIDE_DB:=$MERV_BASE/tmp/mac_shield_override.db}"

# Client name DB: tab-separated "mac<TAB>name". Display-only, main-router only.
# Not pushed to nodes (annotation happens after merged client collection).
: "${MERV_CLIENT_NAME_DB:=$MERV_BASE/tmp/client_name_override.db}"

# ============================================================================
# L2 guard chains — canonical names shared by manager, heal, snapshot, lib
# Defined here (not per-script) so every consumer of lib_mervqt.sh resolves the
# same chain names without divergence. Use ':=' so an explicit env override
# (e.g. for testing) still wins.
# ============================================================================
: "${MERV_QT_CHAIN:=MERV_QT}"                 # L2 quarantine chain (VLAN VAPs in br0)
: "${MERV_DHCP_HOLD_CHAIN:=MERV_DHCP_HOLD}"   # critical-section DHCP kill switch

# DHCP-hold protocol foundation. Production state has one fixed root. Tests may
# override it only when MERV_DHCP_HOLD_TEST_MODE=1 and the replacement resolves
# beneath /tmp/mervlan_tmp/selftest.<run-id>; lib_mervqt.sh validates that
# boundary before performing any state mutation.
: "${MERV_DHCP_HOLD_STATE_ROOT:=$LOCKDIR/dhcp_hold}"
: "${MERV_DHCP_HOLD_LEGACY_MARKER:=$LOCKDIR/merv_dhcp_hold.active}"
: "${MERV_DHCP_HOLD_TEST_MODE:=0}"
: "${MERV_DHCP_HOLD_TEST_ROOT:=}"
: "${MERV_DHCP_HOLD_EBTABLES:=}"
: "${MERV_DHCP_HOLD_PROC_ROOT:=/proc}"
: "${MERV_DHCP_HOLD_FAULT_POINT:=}"

# Live-test guard state is intentionally outside the SSH session. ASUSWRT's
# persistent `cru` scheduler invokes the guard until it is explicitly disarmed
# or its deadline fires.
: "${MERV_LIVE_TEST_GUARD_ROOT:=$TMPDIR/live_test_guard}"
: "${MERV_LIVE_TEST_GUARD_CRON_NAME:=MerVLANLiveTestGuard}"

# Stale-lock reclaim threshold for mervlan_manager.lock. A crashed/killed
# manager leaves its lock directory behind; without age-based reclaim every
# subsequent heal and MERV_MAC recovery would skip forever. 420s (7 min) is
# safely past the longest possible live apply (~3 min incl. node execution)
# while not leaving crashed-manager locks blocking new runs for too long.
: "${MERV_MANAGER_LOCK_STALE_SEC:=420}"

# Stale-lock reclaim threshold for heal_event.sh's vlan_event.lock. Heal fires
# the manager in the background and exits, so it only holds this lock for its
# own pre-checks (wait_for_rc_quiet up to ~120s + checks), never for the full
# manager run. 180s (3 min) safely covers the worst-case heal pass while
# reclaiming a crashed heal's lock quickly. (NOTE: the service-event-handler
# keeps its own local lock timers on purpose — it must stay dependency-free in
# the DHCP-sensitive hot path and is not driven by this value.)
: "${MERV_HEAL_LOCK_STALE_SEC:=180}"

# Stale-lock reclaim threshold for sync_nodes.sh and mac_refresh.sh self-locks.
# Both are non-blocking (skip-on-contention) so this only governs how long a
# CRASHED run's lock blocks the next legitimate run. sync_nodes uses tar-batch
# SSH so a full multi-node push completes in ~10s; 60s gives 2× headroom while
# recovering from crashes quickly.
: "${MERV_SYNC_LOCK_STALE_SEC:=60}"
: "${MERV_MAC_REFRESH_LOCK_STALE_SEC:=60}"

# Bounded node-operation controls.  Node workers accept only one or two SSH
# operations at once; malformed settings are normalized by lib_node_jobs.sh.
: "${MERV_NODE_PARALLELISM:=2}"
: "${MERV_NODE_PREPARE_MAX_SEC:=180}"
: "${MERV_NODE_LAUNCH_MAX_SEC:=180}"
: "${MERV_NODE_SYNC_MAX_SEC:=720}"
: "${MERV_NODE_COMPLETION_MAX_SEC:=600}"
: "${MERV_MAIN_MANAGER_MAX_SEC:=600}"
: "${MERV_NODE_MARKER_POLL_SEC:=5}"
: "${MERV_EXEC_NODES_LOCK_STALE_SEC:=900}"
: "${MERV_NODE_STATUS_RETENTION_SEC:=86400}"
: "${MERV_NODE_STATUS_ROOT:=$RESULTDIR/node_runs}"

# MerVLAN web loading progress is transient task state. It is deliberately
# separate from persistent settings.json and is published to the UI by the
# installer through the public tmp/progress symlink.
: "${MERV_PROGRESS_ROOT:=$TMPDIR/progress}"
: "${MERV_PROGRESS_RETENTION_SEC:=3600}"
: "${MERV_PROGRESS_STALE_SEC:=900}"
: "${MERV_PROGRESS_MAX_FILES:=64}"
: "${MERV_PROGRESS_QUARANTINE_MAX_FILES:=16}"

# SSH trust/capability policy.  A live client must prove it can use a pinned
# host key before an ordinary command or stream is allowed.  The probe adapter
# is deliberately narrow: it captures Dropbear's exact first-contact key in a
# disposable HOME, requests -N, and is killed as soon as the key is written.
# Ordinary SSH calls never inherit its one-time -y behavior.
: "${MERV_SSH_CONNECT_TIMEOUT:=10}"
: "${MERV_SSH_TRUST_TTL_SEC:=31536000}"
: "${MERV_SSH_TRUST_PENDING_TTL_SEC:=300}"
: "${MERV_SSH_TRUST_RETENTION_SEC:=86400}"
: "${MERV_SSH_TRUST_MAX_PENDING:=64}"
: "${MERV_SSH_TRUST_MAX_STAGING:=64}"
: "${MERV_SSH_TRUST_MAX_QUARANTINE:=64}"
: "${MERV_SSH_TRUST_MAX_RECORDS:=64}"
: "${MERV_SSH_HOSTKEY_PROBE_CMD:=$FUNCDIR/ssh_hostkey_probe.sh}"
: "${MERV_SSH_CAPABILITY_PROVEN:=1}"

# Stale-lock reclaim threshold for the unified mac_snapshot.lock. This single
# lock serializes every MAC snapshot path — the cron tick (heal_event.sh), the
# post-apply async snapshot (mervlan_manager.sh) and the manual MAC Refresh
# (mac_refresh.sh) — so the destructive refresh rebuild can never interleave
# with a concurrent snapshot. All holders are non-blocking (skip / retry on
# contention), so this only governs how long a CRASHED holder's lock blocks the
# next run. A full cross-node collect+push over SSH can reach ~60s worst case
# (3 retries × 10s timeout × collect+push per node); 120s gives headroom for
# slow nodes while still reclaiming crashed holders within 2 minutes.
: "${MERV_MAC_SNAPSHOT_LOCK_STALE_SEC:=120}"

# Maximum lifetime of the boot-time DHCP shield watchdog spawned by
# mervlan_boot_wrap.sh shield. Real cold-boot qualification measured about
# 242s from watchdog start through verified manager completion on ASUS
# firmware, so 360s leaves practical boot-storm margin. Token-owned watchdogs
# remain fail-closed at this ceiling if no verified successor completes.
: "${MERV_BOOT_SHIELD_MAX_SEC:=480}"
: "${MERV_BOOT_SHIELD_READY_SEC:=10}"
: "${MERV_HEAL_HANDOFF_ACK_SEC:=10}"
: "${MERV_DHCP_SETTLE_STABLE_SEC:=3}"
: "${MERV_DHCP_SETTLE_MAX_SEC:=60}"
: "${MERV_DHCP_SETTLE_BOOT_MAX_SEC:=150}"
: "${MERV_DHCP_SETTLE_TICK_CMD:=sleep 1}"

# Scripts & Configs
readonly BOOT_SCRIPT="$FUNCDIR/mervlan_boot.sh"
readonly HW_PROBE="$FUNCDIR/hw_probe.sh"
readonly LOG_SETTINGS="$SETTINGSDIR/log_settings.sh"
readonly SSH_KEY="$MERV_BASE/.ssh/vlan_manager"
readonly SSH_PUBKEY="$MERV_BASE/.ssh/vlan_manager.pub"
readonly DROPBEARKEY="/usr/bin/dropbearkey"
readonly SETTINGS_FILE="$SETTINGSDIR/settings.json"
## Hardware settings are now stored in the consolidated settings.json under
## the "Hardware" block. Keep `HW_SETTINGS_FILE` as a compatibility alias
## so existing callers (that expect a path) continue to resolve to a file
## path while the new storage remains a sub-block inside the same JSON.
readonly HW_SETTINGS_FILE="$SETTINGSDIR/settings.json"
readonly OUT_FINAL="$RESULTDIR/vlan_clients.json"
readonly VLAN_MANAGER="$FUNCDIR/mervlan_manager.sh"
readonly SERVICE_EVENT="$FUNCDIR/heal_event.sh"
readonly SYNC_NODES="$FUNCDIR/sync_nodes.sh"
readonly CUSTOM_SETTINGS_FILE="/jffs/addons/custom_settings.txt"
readonly SERVICE_EVENT_HANDLER="$FUNCDIR/service-event-handler.sh"
readonly TEMPLATE_LIB="$MERV_BASE/templates/mervlan_templates.sh"
readonly TEMPLATE_SERVICES="services-start"
readonly TEMPLATE_SERVICE_EVENT="service-event"
readonly TEMPLATE_SERVICE_EVENT_NODES="service-event-nodes"
readonly TEMPLATE_SERVICES_ADDON="services-start-addon"
readonly SERVICES_START="$SCRIPTS_DIR/services-start"
readonly SERVICE_EVENT_WRAPPER="$SCRIPTS_DIR/service-event"

# Logs
readonly LOGFILE="$LOGDIR/mervlan.log"
readonly CLI_LOG="$LOGDIR/cli_output.log"

# Maximum number of supported satellite nodes (NODE1..NODE<MERV_MAX_NODES>).
: "${MERV_MAX_NODES:=10}"

# merv_is_valid_node_id <id> : true if <id> is an integer in 1..MERV_MAX_NODES.
merv_is_valid_node_id() {
  case "$1" in ''|*[!0-9]*) return 1 ;; esac
  [ "$1" -ge 1 ] 2>/dev/null && [ "$1" -le "$MERV_MAX_NODES" ] 2>/dev/null
}


# Flag: settings loaded
VAR_SETTINGS_LOADED=1
