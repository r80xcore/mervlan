#!/bin/sh
#
# ============================================================================ #
#                                                                              #
#   /$$      /$$                     /$$    /$$ /$$        /$$$$$$  /$$   /$$  #
#  | $$$    /$$$                    | $$   | $$| $$       /$$__  $$| $$$ | $$  #
#  | $$$$  /$$$$  /$$$$$$   /$$$$$$ | $$   | $$| $$      | $$  \ $$| $$$$| $$  #
#  | $$ $$/$$ $$ /$$__  $$ /$$__  $$|  $$ / $$/| $$      | $$$$$$$$| $$ $$ $$  #
#  | $$  $$$| $$| $$$$$$$$| $$  \__/ \  $$ $$/ | $$      | $$__  $$| $$  $$$$  #
#  | $$\  $ | $$| $$_____/| $$        \  $$$/  | $$      | $$  | $$| $$\  $$$  #
#  | $$ \/  | $$|  $$$$$$$| $$         \  $/   | $$$$$$$$| $$  | $$| $$ \  $$  #
#  |__/     |__/ \_______/|__/          \_/    |________/|__/  |__/|__/  \__/  #
#                                                                              #
# ============================================================================ #
#             - File: mervlan_manager.sh || version="0.72.2"                #
# ============================================================================ #
# - Purpose:    JSON-driven VLAN manager for Asuswrt-Merlin firmware.          #
#               Applies VLAN settings to SSIDs and Ethernet ports based on     #
#               settings defined in JSON files.                                #
# ============================================================================ #
#                                                                              #
# ================================================== MerVLAN environment setup #
: "${MERV_BASE:=/jffs/addons/mervlan}"
if { [ -n "${VAR_SETTINGS_LOADED:-}" ] && [ -z "${LOG_SETTINGS_LOADED:-}" ]; } || \
   { [ -z "${VAR_SETTINGS_LOADED:-}" ] && [ -n "${LOG_SETTINGS_LOADED:-}" ]; }; then
  unset VAR_SETTINGS_LOADED LOG_SETTINGS_LOADED LIB_JSON_LOADED LIB_SSID_FILTER_LOADED LIB_STP_LOADED LIB_MERVQT_LOADED LIB_MAC_SHIELD_SNAPSHOT_LOADED
fi
[ -n "${VAR_SETTINGS_LOADED:-}" ] || . "$MERV_BASE/settings/var_settings.sh"
[ -n "${LOG_SETTINGS_LOADED:-}" ] || . "$MERV_BASE/settings/log_settings.sh"
[ -n "${LIB_JSON_LOADED:-}" ] || . "$MERV_BASE/settings/lib_json.sh"
[ -n "${LIB_SSID_FILTER_LOADED:-}" ] || . "$MERV_BASE/settings/lib_ssid_filter.sh"
[ -n "${LIB_STP_LOADED:-}" ] || . "$MERV_BASE/settings/lib_stp.sh"
[ -n "${LIB_MERVQT_LOADED:-}" ] || . "$MERV_BASE/settings/lib_mervqt.sh"
[ -n "${LIB_MAC_SHIELD_SNAPSHOT_LOADED:-}" ] || . "$MERV_BASE/settings/mac_shield_snapshot.sh"
[ -n "${LIB_BR0_GUARD_LOADED:-}" ] || . "$MERV_BASE/settings/lib_br0_guard.sh" 2>/dev/null || true
[ -n "${LIB_RADIO_LOADED:-}" ] || . "$MERV_BASE/settings/lib_radio.sh"
# Optional web progress publication. Progress is best-effort and must never
# change the VLAN manager result when the helper or token is unavailable.
merv_action_progress_init() { :; }
merv_action_progress_update() { :; }
merv_action_progress_complete() { :; }
merv_action_progress_fail() { :; }
if [ -f "$MERV_BASE/settings/lib_action_progress.sh" ]; then
  . "$MERV_BASE/settings/lib_action_progress.sh" 2>/dev/null || :
fi
# Runtime marker used by the HTML to block redundant client refreshes during
# applies that started from boot or a service event and have no UI token.
if [ -f "$MERV_BASE/settings/lib_action_runtime.sh" ]; then
  . "$MERV_BASE/settings/lib_action_runtime.sh" 2>/dev/null || :
fi
# Optional CLI overrides:
#   boot                 → boot mode (enables SSID readiness gate)
#   dryrun|--dry-run|-n  → forces dry-run regardless of settings.json
#   --no-collect         → skip collect_clients.sh (for parallel execution)
MERV_MANAGER_MODE="normal"
CLI_DRY_RUN="no"
SKIP_COLLECT="no"
MANAGER_PARENT_RUN_ID=""
MANAGER_HANDOFF_ID=""
for arg in "$@"; do
  case "$arg" in
    boot)
      MERV_MANAGER_MODE="boot"
      ;;
    dryrun|--dry-run|-n)
      CLI_DRY_RUN="yes"
      ;;
    --no-collect)
      SKIP_COLLECT="yes"
      ;;
    --parent-run-id=*)
      MANAGER_PARENT_RUN_ID=${arg#--parent-run-id=}
      ;;
    --handoff-id=*)
      MANAGER_HANDOFF_ID=${arg#--handoff-id=}
      ;;
  esac
done

merv_action_progress_init "${MERV_PROGRESS_TOKEN:-}" "apply_vlanmgr" "Apply VLAN" \
  "Preparing VLAN apply..."

# Boot mode: ensure log directories and files exist before any logging
# This is critical because install.sh may not have run yet on first boot
if [ "$MERV_MANAGER_MODE" = "boot" ]; then
  _boot_logdir="${TMPDIR:-/tmp/mervlan_tmp}/logs"
  mkdir -p "$_boot_logdir" 2>/dev/null || :
  [ -f "$_boot_logdir/cli_output.log" ] || : > "$_boot_logdir/cli_output.log" 2>/dev/null || :
  [ -f "$_boot_logdir/vlan_manager.log" ] || : > "$_boot_logdir/vlan_manager.log" 2>/dev/null || :
  chmod 644 "$_boot_logdir/cli_output.log" "$_boot_logdir/vlan_manager.log" 2>/dev/null || :
  # Trim logs on boot to prevent unbounded growth (see LOG_MAX_LINES in log_settings.sh)
  log_trim_all
fi

# =========================================== End of MerVLAN environment setup #

# ============================================================================ #
# NODE DETECTION — Check if running on a node (satellite) vs main router      #
# ============================================================================ #
# Read IS_NODE and NODE_ID from settings.json (set by execute_nodes.sh)
MERV_IS_NODE="$(json_get_flag IS_NODE 0 "$SETTINGS_FILE")"
MERV_NODE_ID="$(json_get_flag NODE_ID "" "$SETTINGS_FILE")"

# Initialize SSID filter based on node identity (affects which SSIDs we manage)
ssid_filter_init "$MERV_NODE_ID"
info -c vlan "SSID filter: identity=${_SSID_FILTER_TOKEN} node_id=${MERV_NODE_ID:-none}"

# ========================================================================== #
# JSON HELPERS — BusyBox-safe parsing for settings and hardware JSON files    #
# ========================================================================== #

# esc_key — Escape regex-special characters in JSON key names for sed
# Args: $1=key_name
# Returns: escaped key suitable for embedding in sed patterns
esc_key() {
  # Backwards-compatible wrapper: delegate to centralized json_escape_key
  json_escape_key "$@"
}

# read_json_raw — Extract scalar value from JSON file by key name (no NODE_ID remapping)
# Args: $1=key_name, $2=file_path
# Returns: stdout value (quoted string or bare number), or empty if not found
# Explanation: Uses sed with enhanced regex to handle escaped quotes. Prefers
#   quoted strings; falls back to bare values for numbers. Trims whitespace.
read_json_raw() {
  # Backwards-compatible wrapper: delegate to centralized json_get_scalar
  json_get_scalar "$1" "$2"
}

# read_json — Early alias for read_json_raw (pre-NODE_ID wrapper)
# Args: $1=key_name, $2=file_path
# Returns: stdout value from json_get_scalar
read_json() {
  read_json_raw "$@"
}

# read_json_number — Extract numeric value from JSON key (grep only digits)
# Args: $1=key_name, $2=file_path
# Returns: stdout numeric value, or empty if not found or non-numeric
read_json_number() {
  # Backwards-compatible wrapper: reuse json_get_int
  json_get_int "$1" "" "$2"
}

# read_json_section_value — Extract a string value from a nested JSON object
# Args: <section> <key> <file>
# Returns: matching string value or empty
read_json_section_value() {
  # Backwards-compatible wrapper: delegate to centralized json_get_section_value
  json_get_section_value "$1" "$2" "$3"
}

# read_json_section_number — Similar to read_json_section_value but returns numeric digits only
read_json_section_number() {
  # Backwards-compatible wrapper: delegate to centralized json_get_section_int
  json_get_section_int "$1" "$2" "$3"
}

# read_json_section_array — Extract a nested JSON array or fallback to a string
# Returns: space-separated list (quotes removed)
read_json_section_array() {
  # Backwards-compatible wrapper: delegate to centralized json_get_section_array
  json_get_section_array "$1" "$2" "$3"
}

# read_json_array — Extract JSON array and flatten to space-separated values
# Args: $1=key_name, $2=file_path
# Returns: stdout space-separated values (quotes and commas removed)
# Explanation: Extracts [a,b,c] bracket content, removes whitespace/quotes/commas
read_json_array() {
  # Backwards-compatible wrapper: delegate to centralized json_get_array
  json_get_array "$1" "$2"
}

detect_trunks_configured() {
  local idx val
  idx=1
  while [ $idx -le 8 ]; do
    val=$(read_json_number "TRUNK${idx}" "$SETTINGS_FILE")
    [ -z "$val" ] && val=$(read_json_number "trunk${idx}" "$SETTINGS_FILE")
    [ -z "$val" ] && val=$(json_get_section2_int "VLAN" "Trunks" "TRUNK${idx}" "$SETTINGS_FILE" 2>/dev/null)
    [ -z "$val" ] && val=$(json_get_section2_int "VLAN" "Trunks" "trunk${idx}" "$SETTINGS_FILE" 2>/dev/null)
    case "$val" in ''|0) ;; *) return 0 ;; esac
    idx=$((idx + 1))
  done
  return 1
}

run_trunk_if_configured() {
  TRUNK_APPLIED=0

  if ! detect_trunks_configured; then
    info -c cli,vlan "No trunk configuration enabled. Skipping."
    return 0
  fi

  info -c cli,vlan "Trunk config detected. Running trunk script..."

  if [ ! -x "$FUNCDIR/mervlan_trunk.sh" ]; then
    info -c cli,vlan "Node/remote AP: trunk script not present; skipping trunk config"
    return 0
  fi

  if DRY_RUN="$DRY_RUN" UPLINK_PORT="$UPLINK_PORT" DEFAULT_BRIDGE="$DEFAULT_BRIDGE" MAX_TRUNKS=8 \
      "$FUNCDIR/mervlan_trunk.sh"; then
    TRUNK_APPLIED=1
    return 0
  fi

  warn -c cli,vlan "Trunk script execution failed"
  return 1
}

# ========================================================================== #
# STRING NORMALIZATION HELPERS — ensure consistent SSID and interface matching #
# ========================================================================== #

normalize_basic() {
  val="$1"
  val=$(printf '%s' "$val" | tr -d '\r\357\273\277\342\200\213\342\200\214\342\200\215')
  printf '%s' "$val" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'
}

normalize_iface() {
  normalize_basic "$1"
}

normalize_ssid() {
  val=$(normalize_basic "$1")
  printf '%s' "$val" | sed \
    -e 's/—/-/g' -e 's/–/-/g' \
    -e "s/[‘’]/'/g" -e 's/[“”]/"/g'
}

to_lower() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]'
}

BOUND_IFACES=""
WATCH_IFACES=""
TRUNK_APPLIED=0

# ========================================================================== #
# INITIALIZATION & HARDWARE DETECTION — Load configs and validate setup       #
# ========================================================================== #

# Verify required settings files exist; exit if missing
[ -f "$HW_SETTINGS_FILE" ] || { error -c cli,vlan "Missing $HW_SETTINGS_FILE"; exit 1; }
[ -f "$SETTINGS_FILE" ] || { error -c cli,vlan "Missing $SETTINGS_FILE"; exit 1; }

# Extract hardware profile from hardware settings. Supports both a standalone
# hw_settings.json (legacy) as well as the consolidated Hardware block inside
# settings.json. We try top-level reads first for backward compatibility, then
# probe the nested Hardware object when present.
MODEL=$(read_json MODEL "$HW_SETTINGS_FILE")
if [ -z "$MODEL" ]; then
  MODEL=$(read_json_section_value "Hardware" "MODEL" "$HW_SETTINGS_FILE")
fi

PRODUCTID=$(read_json PRODUCTID "$HW_SETTINGS_FILE")
if [ -z "$PRODUCTID" ]; then
  PRODUCTID=$(read_json_section_value "Hardware" "PRODUCTID" "$HW_SETTINGS_FILE")
fi

MAX_SSIDS=$(read_json_number MAX_SSIDS "$HW_SETTINGS_FILE")
if [ -z "$MAX_SSIDS" ]; then
  MAX_SSIDS=$(read_json_section_number "Hardware" "MAX_SSIDS" "$HW_SETTINGS_FILE")
fi

# ETH_PORTS is an array in the legacy format, but may be stored either as a
# JSON array or as a space-separated string inside the Hardware block. Try
# both extraction methods and normalize to space-separated values.
ETH_PORTS=$(read_json_array ETH_PORTS "$HW_SETTINGS_FILE")
if [ -z "$ETH_PORTS" ]; then
  ETH_PORTS=$(read_json_section_array "Hardware" "ETH_PORTS" "$HW_SETTINGS_FILE")
fi

WAN_IF=$(read_json WAN_IF "$HW_SETTINGS_FILE")
if [ -z "$WAN_IF" ]; then
  WAN_IF=$(read_json_section_value "Hardware" "WAN_IF" "$HW_SETTINGS_FILE")
fi

# Extract user configuration from settings.json
TOPOLOGY="switch"
PERSISTENT=$(read_json_raw PERSISTENT "$SETTINGS_FILE")
DRY_RUN=$(read_json_raw DRY_RUN "$SETTINGS_FILE")
ENABLE_STP=$(read_json_raw ENABLE_STP "$SETTINGS_FILE")
# Extract the override for tagging native SSIDs (wl0/wl1 directly to VLAN)
ENABLE_NATIVE_SSID=$(read_json_raw ENABLE_NATIVE_SSID "$SETTINGS_FILE")

# Extract NODE_ID early (before node-aware read_json wrapper is defined)
NODE_ID=$(read_json_raw NODE_ID "$SETTINGS_FILE")
if [ -z "$NODE_ID" ]; then
  NODE_ID=$(read_json_section_value "General" "NODE_ID" "$SETTINGS_FILE")
fi
[ -z "$NODE_ID" ] && NODE_ID="none"

# Normalize invalid NODE_IDs to prevent unexpected behavior
case "$NODE_ID" in
  none|'') : ;;
  *) merv_is_valid_node_id "$NODE_ID" 2>/dev/null || NODE_ID="none" ;;
esac

# Apply defaults for unconfigured values
[ -z "$MAX_SSIDS" ] && MAX_SSIDS=12
MAX_SSIDS=$(merv_cap_ssids "$MAX_SSIDS" "$SETTINGS_FILE")
[ -z "$PERSISTENT" ] && PERSISTENT="no"
[ -z "$DRY_RUN" ] && DRY_RUN="yes"
[ -z "$WAN_IF" ] && WAN_IF="eth0"
[ -z "$ENABLE_STP" ] && ENABLE_STP="0"

# CLI "dryrun" forces DRY_RUN=yes regardless of settings.json
if [ "$CLI_DRY_RUN" = "yes" ]; then
  DRY_RUN="yes"
  info -c cli,vlan "Dry-run forced by CLI argument; ignoring DRY_RUN setting"
fi

case "$ENABLE_STP" in
  1) ENABLE_STP=1 ;;
  *) ENABLE_STP=0 ;;
esac

case "$ENABLE_NATIVE_SSID" in
  1) ENABLE_NATIVE_SSID=1 ;;
  *) ENABLE_NATIVE_SSID=0 ;;
esac

# Temporarily force non-persistent mode until feature is fixed
if [ "$PERSISTENT" != "no" ]; then
  warn -c cli,vlan "Persistent mode is forced off pending fixes; running non-persistent"
fi
PERSISTENT="no"

# Resolve bridge and WAN interface
UPLINK_PORT="$WAN_IF"
DEFAULT_BRIDGE="br0"

# ========================================================================== #
# NODE-AWARE read_json WRAPPER — Intercept ETH VLAN reads for node overrides #
# ========================================================================== #

# read_json — Smart wrapper that redirects ETH*_VLAN reads based on NODE_ID
# Args: $1=key_name, $2=file_path
# Returns: stdout value from appropriate pool (node override or main)
# Explanation: When NODE_ID is 1-5, intercepts ETH1_VLAN..ETH8_VLAN reads
#   and redirects to NODE{n}_ETH{idx}_VLAN. No fallback to main pool.
#   All other keys pass through to read_json_raw unchanged.
read_json() {
  local key="$1"
  local file="$2"
  local idx okey val

  # Only redirect ETH port VLAN reads, only for settings.json, only on nodes
  if merv_is_valid_node_id "$NODE_ID" 2>/dev/null; then
      if [ "$file" = "$SETTINGS_FILE" ]; then
        case "$key" in
          ETH[1-8]_VLAN)
            idx="${key#ETH}"      # "1_VLAN"
            idx="${idx%_VLAN}"    # "1"
            okey="NODE${NODE_ID}_ETH${idx}_VLAN"

            val="$(read_json_raw "$okey" "$file")"
            [ -z "$val" ] && val="none"   # strict modular: no fallback to main
            printf '%s' "$val"
            return 0
            ;;
        esac
      fi
  fi

  # Main unit (NODE_ID=none) or non-ETH keys: normal read
  read_json_raw "$key" "$file"
}

# ========================================================================== #
# STATE TRACKING & AUDIT — Change log, cleanup on exit, change tracking      #
# ========================================================================== #

# Fail fast if critical directories are unset to avoid writing to /
# In dry-run mode we intentionally avoid creating or touching state/log folders
if [ "$DRY_RUN" != "yes" ]; then
  [ -n "$CHANGES" ] || { error -c cli,vlan "CHANGES not set"; exit 1; }
  [ -n "$LOCKDIR" ] || { error -c cli,vlan "LOCKDIR not set"; exit 1; }

  # Ensure change-tracking and lock directories exist before use
  [ -d "$CHANGES" ] || mkdir -p "$CHANGES" 2>/dev/null || :
  [ -d "$LOCKDIR" ] || mkdir -p "$LOCKDIR" 2>/dev/null || :

  # Per-execution change log (cleaned up on exit via trap)
  CHANGE_LOG="$CHANGES/vlan_changes.$$"
  LOCK_PATH="$LOCKDIR/mervlan_manager.lock"
else
  # Dry-run: keep these unset or empty so helpers are no-op
  CHANGE_LOG=""
  LOCK_PATH=""
fi

LOCK_ACQUIRED=0
MANAGER_DHCP_TOKEN=""
MANAGER_RUN_ID=""
MANAGER_EXIT_REASON="process-exit"
MANAGER_RUNTIME_OWNED=0

acquire_script_lock() {
  # Prevent concurrent runs from stomping on bridges/interfaces. The owner-aware
  # identity/nonce primitive lives in lib_mervqt.sh so heal, MAC Shield refresh,
  # and this manager share one contract. Live owners are never reclaimed by age;
  # unknown metadata fails closed.
  [ "$DRY_RUN" = "yes" ] && return 0
  [ -n "$LOCK_PATH" ] || return 0

  # Courtesy yield to an in-flight heal: heal is non-blocking and short-lived,
  # so a single brief wait lets it finish reading interface state before we
  # start mutating bridges. This is a BEST-EFFORT yield only — we NEVER abort
  # or reclaim heal's lock here. The final owner-aware acquisition below is
  # authoritative: active or unknown ownership is never bypassed by this wait.
  if type merv_lock_state >/dev/null 2>&1; then
    case "$(merv_lock_state "$LOCKDIR/vlan_event.lock")" in
      active|unknown)
        info -c cli,vlan "Manager: heal in flight — yielding briefly before apply"
        sleep 3
        ;;
    esac
  fi

  local stale
  stale="${MERV_MANAGER_LOCK_STALE_SEC:-420}"
  if merv_lock_acquire "$LOCK_PATH" "$stale" 30 "mervlan_manager"; then
    LOCK_ACQUIRED=1
    MANAGER_LOCK_NONCE="${MERV_LOCK_NONCE:-}"
    if [ "${MERV_ACTION_RUNTIME_OWNER:-0}" != "1" ] &&
       type merv_action_runtime_start >/dev/null 2>&1 &&
       merv_action_runtime_start "apply_vlanmgr" "Apply VLAN" \
         "Applying VLAN configuration..."; then
      MANAGER_RUNTIME_OWNED=1
    fi
  else
    error -c cli,vlan "Could not acquire mervlan_manager lock; aborting"
    exit 1
  fi
}

release_script_lock() {
  # No-op in dry-run
  [ "$DRY_RUN" = "yes" ] && return 0
  [ "$LOCK_ACQUIRED" -eq 1 ] || return
  if merv_lock_release "$LOCK_PATH" "$MANAGER_LOCK_NONCE"; then
    LOCK_ACQUIRED=0
    return 0
  fi
  error -c cli,vlan "Could not release mervlan_manager owner lock; recovery is required"
  return 1
}

cleanup_on_exit() {
    _cleanup_rc=$?
    _cleanup_failed=0
    if [ -n "${MANAGER_DHCP_TOKEN:-}" ]; then
      _cleanup_reason="${MANAGER_EXIT_REASON:-exit}-${_cleanup_rc}"
      if merv_dhcp_hold_abandon "$MANAGER_DHCP_TOKEN" "$_cleanup_reason"; then
        MANAGER_DHCP_TOKEN=""
      else
        error -c cli,vlan "Manager cleanup could not resolve its DHCP lease; reconciliation queued"
      fi
    fi
    if [ "${MANAGER_RUNTIME_OWNED:-0}" -eq 1 ] && ! merv_action_runtime_finish 2>/dev/null; then
      _cleanup_failed=1
      error -c cli,vlan "Manager cleanup could not release the action-runtime marker"
    fi
    # Remove per-execution change log file
    if [ -f "$CHANGE_LOG" ] && ! rm -f "$CHANGE_LOG" 2>/dev/null; then
      _cleanup_failed=1
      error -c cli,vlan "Manager cleanup could not remove its change log"
    fi
    release_script_lock || _cleanup_failed=1
    [ "$_cleanup_failed" -eq 0 ] || _cleanup_rc=1
    if [ "${MERV_ACTION_PROGRESS_ENABLED:-0}" -eq 1 ] &&
       [ "${MERV_ACTION_PROGRESS_FINAL:-0}" -eq 0 ]; then
      if [ "$_cleanup_rc" -eq 0 ]; then
        merv_action_progress_complete "Apply complete"
      else
        merv_action_progress_fail "Apply failed; see the VLAN log for details"
      fi
    fi
    return "$_cleanup_rc"
}
trap 'MANAGER_EXIT_REASON=signal-int; exit 130' INT
trap 'MANAGER_EXIT_REASON=signal-term; exit 143' TERM
trap cleanup_on_exit EXIT

# track_change — Log configuration changes with timestamp for audit trail
# Args: $1=change_description (string)
# Returns: none (appends to $CHANGE_LOG)
track_change() {
  # Skip writing change-log in dry-run mode
  [ "$DRY_RUN" = "yes" ] && return 0
  [ -n "$CHANGE_LOG" ] || return 0
  # Append change with ISO timestamp and shell PID for tracking
  echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> "$CHANGE_LOG"
}

# ========================================================================== #
# CONFIGURATION VALIDATION — Pre-flight checks and sanity validation         #
# ========================================================================== #

# validate_configuration — Verify settings and hardware files exist and warn on defaults
# Args: none (uses global paths $SETTINGS_FILE, $HW_SETTINGS_FILE)
# Returns: none (exits if critical files missing, warns on missing values)
validate_configuration() {
  # Check for required configuration files
  [ -f "$SETTINGS_FILE" ] || error -c cli,vlan "Settings file missing"
  [ -f "$HW_SETTINGS_FILE" ] || error -c cli,vlan "Hardware settings file missing"
  # Warn on missing hardware identification (non-critical, uses defaults)
  [ -n "$MODEL" ] || warn -c cli,vlan "MODEL not defined in hardware settings; using defaults"
  [ -n "$PRODUCTID" ] || warn -c cli,vlan "PRODUCTID not defined in hardware settings; using defaults"
  # Warn on missing capacity hints (non-critical, uses defaults)
  [ -n "$MAX_SSIDS" ] || warn -c cli,vlan "MAX_SSIDS not defined; defaulting to 12"
  [ -n "$ETH_PORTS" ] || warn -c cli,vlan "ETH_PORTS not defined; no Ethernet ports will be configured"
}

# wait_for_interface — Poll interface with exponential backoff until ready or timeout
# Args: $1=interface_name
# Returns: 0 if interface exists, 1 if timeout after ~63 seconds
# Explanation: Exponential backoff prevents busy-waiting. Useful for VAPs that appear after wireless restart.
wait_for_interface() {
  local iface="$1" max_attempts=6 attempt=0
  # Poll up to 6 times with exponential sleep: 1s, 2s, 4s, 8s, 16s, 32s (~63s total)
  while [ $attempt -lt $max_attempts ]; do
    # Check if interface exists in /sys/class/net
    iface_exists "$iface" && return 0

    # Active shield defense during backoff — a late rc wakeup during a long
    # exponential wait can wipe ebtables while bind_configured_ssids is still
    # waiting for a slow interface. One unified guard tick restores QT + MAC +
    # DHCP hold from a single ebtables read, each path fast-pathing to a no-op
    # when its chain and jumps are intact (no expensive rebuild per attempt).
    merv_guard_tick

    # Exponential backoff: 1<<attempt seconds (BusyBox-safe)
    sleep $((1 << attempt))
    attempt=$((attempt + 1))
  done
  # Timeout: interface never appeared
  warn -c cli,vlan "Interface $iface did not appear within ~63s (skipping)"
  return 1
}

# ========================================================================== #
# CORE VLAN FUNCTIONS — Bridge management, VLAN creation, interface attachment  #
# ========================================================================== #

# iface_exists — Check if network interface exists in kernel
# Args: $1=interface_name
# Returns: 0 if present, 1 if not found
iface_exists() { [ -d "/sys/class/net/$1" ]; }

# is_number — Check if string is a valid integer
# Args: $1=value
# Returns: 0 if integer, 1 otherwise
is_number()    { expr "$1" + 0 >/dev/null 2>&1; }

# ssid_configured_for_iface — true if nvram has a non-empty SSID for this wl iface
# Args: $1=iface_name like wl0.1
# Returns: 0 if configured, 1 otherwise
ssid_configured_for_iface() {
  local ifn ssid
  ifn="$1"

  ssid="$(nvram get "${ifn}_ssid" 2>/dev/null)"
  ssid="$(printf '%s' "$ssid" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/^"//; s/"$//')"

  [ -n "$ssid" ] || return 1
  case "$ssid" in
    ''|0|null|NULL) return 1 ;;
  esac

  return 0
}

# is_internal_vap — Detect VAPs that are not user SSIDs
# Rule: wlX.Y is internal only if nvram key wlX.Y_ssid is missing/empty.
# Never block wlX base radios or eth*.
is_internal_vap() {
  local ifn
  ifn="$1"

  [ -n "$ifn" ] || return 1

  case "$ifn" in
    eth*) return 1 ;;
  esac

  # Base radios (wl0, wl1, ..., wl99) are never internal VAPs
  merv_is_wl_base_radio "$ifn" && return 1

  # Strict VAP check: slot portion must be a pure unsigned integer
  if merv_is_wl_vap_iface "$ifn"; then
    ssid_configured_for_iface "$ifn" && return 1
    return 0
  fi

  # Unknown interface types: treat as non-internal by default
  return 1
}

# is_wl_iface — Check if interface is a Broadcom wireless interface usable by wl
# Args: $1=interface_name
# Returns: 0 if wl -i IF status succeeds, 1 otherwise
is_wl_iface() {
  local ifn
  ifn="$1"
  [ -n "$ifn" ] || return 1
  iface_exists "$ifn" || return 1
  wl -i "$ifn" status >/dev/null 2>&1
}

# is_native_radio — Check if interface is a primary/native radio
# Args: $1=interface_name
# Returns: 0 if native (wl0, wl1, ..., wl99), 1 if guest (wl0.1) or ethernet
# Note: Moving native radios to VLAN bridges can break Broadcom firmware routing.
is_native_radio() {
  merv_is_wl_base_radio "$1"
}

# validate_vlan_id — Check if VLAN ID is valid (1-4094 reserved range)
# Args: $1=vlan_id (number, "none", "trunk", or empty)
# Returns: 0 if valid, 1 if invalid
# Explanation: VLAN 1 is reserved LAN (native). Valid user VLANs: 2-4094. Special: "none"=untagged, "trunk"=passthrough
validate_vlan_id() {
  case "$1" in
   ""|none|trunk) return 0 ;;
  esac

  # Check numeric range: only 2-4094 allowed (1 is reserved LAN)
  if is_number "$1"; then
    if [ "$1" -eq 1 ]; then
      error -c cli,vlan "VLAN 1 is reserved (native LAN). Use VLAN_ID=none instead."
      return 1
    fi
    if [ "$1" -ge 2 ] && [ "$1" -le 4094 ]; then
      return 0
    fi
  fi

  error -c cli,vlan "Invalid VLAN: $1"
  return 1
}

# remove_from_all_bridges — Detach interface from all bridges (cleanup before reassignment)
# Args: $1=interface_name
# Returns: none (best-effort, ignores errors)
remove_from_all_bridges() {
  local iface br
  iface="$1"

  [ "$DRY_RUN" = "yes" ] && {
    info -c cli,vlan "[DRY-RUN] would detach $iface from all bridges"
    return 0
  }

  brctl show 2>/dev/null \
    | awk 'NR>1 && $1!="" {print $1}' \
    | sort -u \
    | while read -r br; do
        brctl delif "$br" "$iface" 2>/dev/null
      done
}

# ensure_vlan_bridge — Create VLAN interface and bridge if not present
# Args: $1=vlan_id
# Returns: 0 on success, 1 on failure
# Explanation: Creates eth0.VID (VLAN interface) and brVID (bridge) for tagged traffic
ensure_vlan_bridge() {
  VID="$1"
  # Skip special cases: "none" and "trunk" don't need infrastructure
  if [ "$VID" = "none" ] || [ "$VID" = "trunk" ]; then
    return 0
  fi

  # ---- Uplink VLAN sub-interface (needed by every path below) ----
  if ! iface_exists "${UPLINK_PORT}.${VID}"; then
    if [ "$DRY_RUN" = "yes" ]; then
      echo "[DRY-RUN] ip link add link $UPLINK_PORT name ${UPLINK_PORT}.${VID} type vlan id $VID"
      echo "[DRY-RUN] ip link set ${UPLINK_PORT}.${VID} up"
    else
      ip link add link "$UPLINK_PORT" name "${UPLINK_PORT}.${VID}" type vlan id "$VID" 2>/dev/null || \
      iface_exists "${UPLINK_PORT}.${VID}" || {
        error -c cli,vlan "Failed to create VLAN interface ${UPLINK_PORT}.${VID}"
        return 1
      }
      ip link set "${UPLINK_PORT}.${VID}" up 2>/dev/null
      info -c cli,vlan "Created VLAN interface ${UPLINK_PORT}.${VID}"
      track_change "Created VLAN interface ${UPLINK_PORT}.${VID}"
    fi
  fi

  # ---- Bridge (sysfs-first detection) ----
  if ! iface_exists "br${VID}"; then
    # --- New bridge ---
    if [ "$DRY_RUN" = "yes" ]; then
      echo "[DRY-RUN] brctl addbr br${VID}"
      stp_set_bridge_mac "$VID" "$DRY_RUN"
      echo "[DRY-RUN] brctl addif br${VID} ${UPLINK_PORT}.${VID}"
      echo "[DRY-RUN] ip link set br${VID} up"
      stp_apply_policy "$VID" "$DRY_RUN" "${ENABLE_STP:-0}"
    else
      # 1. Create bridge
      brctl addbr "br${VID}" 2>/dev/null || {
        error -c cli,vlan "Failed to create bridge br${VID}"
        return 1
      }
      # 2. Set deterministic MAC while bridge is still empty/down
      if ! stp_set_bridge_mac "$VID" "$DRY_RUN"; then
        if [ "${ENABLE_STP:-0}" -eq 1 ] 2>/dev/null; then
          error -c cli,vlan "ensure_vlan_bridge: FATAL — MAC set failed on new br${VID} with STP enabled; removing bridge"
          brctl delbr "br${VID}" 2>/dev/null
          return 1
        fi
        warn -c cli,vlan "ensure_vlan_bridge: MAC set failed on new br${VID} (STP off, continuing)"
      fi
      # 3. Add uplink VLAN interface
      brctl addif "br${VID}" "${UPLINK_PORT}.${VID}" 2>/dev/null || {
        error -c cli,vlan "Failed to attach uplink ${UPLINK_PORT}.${VID} to br${VID}"
        brctl delbr "br${VID}" 2>/dev/null
        return 1
      }
      # 4. Bring bridge up
      ip link set "br${VID}" up 2>/dev/null
      # 5. STP policy
      stp_apply_policy "$VID" "$DRY_RUN" "${ENABLE_STP:-0}"
      info -c cli,vlan "Created bridge br${VID}"
      track_change "Created bridge br${VID}"
    fi
  else
    # --- Existing bridge: enforce MAC + policy ---
    if [ "${ENABLE_STP:-0}" -eq 1 ] 2>/dev/null; then
      if ! stp_force_bridge_mac "$VID" "$DRY_RUN"; then
        error -c cli,vlan "ensure_vlan_bridge: FATAL — failed to enforce bridge MAC on br${VID} with STP enabled"
        return 1
      fi
    else
      stp_set_bridge_mac "$VID" "$DRY_RUN"
    fi
    # Ensure uplink VLAN iface is a member (force-mac may have detached it)
    if [ "$DRY_RUN" = "yes" ]; then
      echo "[DRY-RUN] ensure ${UPLINK_PORT}.${VID} is member of br${VID}"
    else
      if ! member_of_bridge "br${VID}" "${UPLINK_PORT}.${VID}"; then
        brctl addif "br${VID}" "${UPLINK_PORT}.${VID}" 2>/dev/null || {
          error -c cli,vlan "ensure_vlan_bridge: FATAL — could not attach uplink ${UPLINK_PORT}.${VID} to br${VID}"
          return 1
        }
        info -c cli,vlan "ensure_vlan_bridge: re-attached uplink ${UPLINK_PORT}.${VID} to br${VID}"
      fi
      # Best-effort: make sure bridge is up
      ip link set "br${VID}" up 2>/dev/null
      # Post-enforcement verification (STP only — log mismatch for diagnostics)
      if [ "${ENABLE_STP:-0}" -eq 1 ] 2>/dev/null; then
        stp_verify_bridge_mac "$VID" || {
          error -c cli,vlan "ensure_vlan_bridge: FATAL — bridge MAC verification failed on br${VID}"
          return 1
        }
      fi
    fi
    stp_apply_policy "$VID" "$DRY_RUN" "${ENABLE_STP:-0}"
  fi
}

member_of_bridge_brctl_fallback() {
  br="$1"
  iface="$2"
  [ -n "$br" ] && [ -n "$iface" ] || return 1
  brctl show 2>/dev/null | awk -v BR="$br" -v IF="$iface" '
    NR==1 { next }
    {
      if ($1 != "") cur=$1
      for (i=1; i<=NF; i++) {
        gsub(/\r/, "", $i)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", $i)
      }
      if (cur==BR) {
        for (i=1; i<=NF; i++) {
          if ($i == IF) { found=1; exit }
        }
      }
    }
    END { exit(found?0:1) }
  ' >/dev/null 2>&1
}

member_of_bridge_sysfs() {
  br="$1"
  iface="$2"
  [ -n "$br" ] && [ -n "$iface" ] || return 1
  [ -d "/sys/class/net/$br" ] || return 1
  [ -e "/sys/class/net/$br/brif/$iface" ]
}

member_of_bridge() {
  br="$1"
  iface="$2"
  member_of_bridge_sysfs "$br" "$iface" && return 0
  member_of_bridge_brctl_fallback "$br" "$iface"
}

verify_interface_binding() {
  iface="$1"
  vid="$2"
  case "$vid" in
    none|trunk) return 0 ;;
  esac
  member_of_bridge "br${vid}" "$iface"
}

# attach_to_bridge — Attach interface to appropriate bridge based on VLAN config
# Args: $1=interface, $2=vlan_id, $3=label (for logging)
# Returns: none (logs errors, continues on non-critical failures)
# Explanation: Validates VLAN, filters internal VAPs, ensures bridge exists, adds interface
attach_to_bridge() {
  IF="$1"
  VID="$2"
  LABEL="$3"

  # Validate VLAN ID before attempting attachment
  validate_vlan_id "$VID" || { warn -c cli,vlan "Invalid VLAN $VID for $LABEL, skipping"; return; }

  # Skip VAPs flagged as internal (those without a configured SSID)
  is_internal_vap "$IF" && { warn -c cli,vlan "$LABEL ($IF) looks internal; skipping"; return; }
  # Verify interface exists in kernel before attachment
  iface_exists "$IF" || { warn -c cli,vlan "$LABEL ($IF) - not present, skipping"; return; }

  # Idempotency guard for br0 attachments: if the interface is already in
  # br0 and the target is also br0 (VID=none), skip remove+reattach.
  # Briefly detaching native radios (wl0, wl1) from br0 causes Broadcom
  # firmware to reset nas auth state for that interface, destroying the
  # PSK association. VLAN-bound interfaces always move unconditionally so
  # correct placement is enforced after firmware resets.
  if [ "$VID" = "none" ] && [ "$DRY_RUN" != "yes" ] && member_of_bridge "$DEFAULT_BRIDGE" "$IF"; then
    info -c cli,vlan "$LABEL -> $DEFAULT_BRIDGE (already; no-op)"
    ebt_quarantine_release "$IF"
    note_bound_iface "$IF"
    return 0
  fi

  # DHCP-isolation gate: bring wl subinterfaces down BEFORE the bridge detach
  # so no client can grab a br0 DHCP lease during the bridge-move window.
  # Applies only to wl subinterfaces (wl0.1, wl1.1, …) being placed into a
  # VLAN bridge. Base radios (wl0, wl1) and eth ports are excluded to avoid
  # dropping all clients on a radio or severing the uplink.
  _wl_gate=0
  case "$VID" in
    none|trunk) ;;
    *)
      if [ "$DRY_RUN" != "yes" ] && is_wl_iface "$IF" && ! is_native_radio "$IF"; then
        wl -i "$IF" down 2>/dev/null && _wl_gate=1
        [ "$_wl_gate" -eq 1 ] && info -c cli,vlan "DHCP gate: $IF down (bridge move pending)"
      fi
      ;;
  esac

  # Detach from all bridges before reattachment (unless dry-run mode)
  [ "$DRY_RUN" = "yes" ] || remove_from_all_bridges "$IF"

  # Attach interface to appropriate bridge based on VLAN ID
  case "$VID" in
    none)
      # Attach to default bridge br0 (untagged LAN)
      if [ "$DRY_RUN" = "yes" ]; then
        echo "[DRY-RUN] brctl addif $DEFAULT_BRIDGE $IF"
      else
        brctl addif "$DEFAULT_BRIDGE" "$IF" 2>/dev/null || {
          error -c cli,vlan "Failed to attach $IF to $DEFAULT_BRIDGE"
          return 1
        }
        info -c cli,vlan "$LABEL -> $DEFAULT_BRIDGE (untagged)"
        track_change "Attached $IF to $DEFAULT_BRIDGE (untagged)"
        # Lift quarantine: this interface is correctly in br0. Remove its DROP
        # rule so native br0 traffic (DHCP from main pool, etc.) flows normally.
        ebt_quarantine_release "$IF"
      fi
      note_bound_iface "$IF"
      ;;
    trunk)
      # Trunk mode: leave unconfigured (passthrough, no bridge)
      info -c cli,vlan "$LABEL set as trunk (no bridge)"
      note_bound_iface "$IF"
      ;;
    *)
      # Attach to VLAN bridge (e.g., br100 for VLAN 100)
      ensure_vlan_bridge "$VID" || { [ "$_wl_gate" -eq 1 ] && wl -i "$IF" up 2>/dev/null; return 1; }
      if [ "$DRY_RUN" = "yes" ]; then
        echo "[DRY-RUN] brctl addif br${VID} $IF"
        note_bound_iface "$IF"
      else
        brctl addif "br${VID}" "$IF" 2>/dev/null || {
          error -c cli,vlan "Failed to attach $IF to br${VID}"
          [ "$_wl_gate" -eq 1 ] && wl -i "$IF" up 2>/dev/null
          return 1
        }
        # Restore VAP now that it is correctly placed in its VLAN bridge
        [ "$_wl_gate" -eq 1 ] && { wl -i "$IF" up 2>/dev/null; info -c cli,vlan "DHCP gate: $IF up (in br${VID})"; }
        info -c cli,vlan "$LABEL -> br${VID} (VLAN $VID)"
        track_change "Attached $IF to br${VID} (VLAN $VID)"
        if ! verify_interface_binding "$IF" "$VID"; then
          sleep 2
          brctl addif "br${VID}" "$IF" 2>/dev/null || true
          verify_interface_binding "$IF" "$VID" >/dev/null 2>&1 || :
        fi
        note_bound_iface "$IF"
        queue_watch "$IF,$VID"
      fi
      ;;
  esac
}

note_bound_iface() {
  local iface
  iface=$(normalize_iface "$1")
  [ -n "$iface" ] || return 0
  case " $BOUND_IFACES " in
    *" $iface "*) return 0 ;;
  esac
  BOUND_IFACES="$BOUND_IFACES $iface"
}

queue_watch() {
  raw="$1"
  iface_part=$(normalize_iface "${raw%,*}")
  vid_part="${raw#*,}"
  [ -n "$iface_part" ] || return 0
  kv="${iface_part},${vid_part}"
  in_list=0
  case " $WATCH_IFACES " in
    *" $kv "*) in_list=1 ;;
  esac
  [ $in_list -eq 0 ] && WATCH_IFACES="$WATCH_IFACES $kv"

  # Log on second pass even if already queued previously
  if [ "${WATCHDOG_QUEUE_LOG:-0}" = "1" ]; then
    info -c cli,vlan "staging ${iface_part} -> br${vid_part} for watchdog verification"
  fi
}

iface_bound() {
  local iface
  iface=$(normalize_iface "$1")
  [ -n "$iface" ] || return 1
  case " $BOUND_IFACES " in
    *" $iface "*) return 0 ;;
  esac
  return 1
}

# ========================================================================== #
# SSID RESOLUTION — Find wireless interfaces by SSID name                    #
# ========================================================================== #

# find_if_by_ssid — Locate interface on specific band by SSID name
# Args: $1=band (0|1|2), $2=ssid_name
# Returns: stdout interface_name (e.g., wl0, wl0.1), or empty if not found
# Explanation: Resolves from nvram first, then callers wait for the interface
#   to appear. This avoids dropping later-starting bands during boot/restart.
find_if_by_ssid() {
  BAND="$1"
  TARGET="$2"

  TARGET_NORM=$(normalize_ssid "$TARGET")
  [ -z "$TARGET_NORM" ] && return 1
  [ "$TARGET_NORM" = "unused-placeholder" ] && return 1
  TARGET_LOWER=$(to_lower "$TARGET_NORM")

  FALLBACK_IFACE=""
  FALLBACK_LABEL=""
  FALLBACK_COUNT=0

  SSID_BASE="$(nvram get wl${BAND}_ssid 2>/dev/null)"
  IF_BASE="$(nvram get wl${BAND}_ifname 2>/dev/null)"
  IF_BASE=$(normalize_iface "$IF_BASE")
  if [ -n "$IF_BASE" ]; then
    BASE_NORM=$(normalize_ssid "$SSID_BASE")
    if [ "$BASE_NORM" = "$TARGET_NORM" ]; then
      echo "$IF_BASE"
      return 0
    fi
    if [ -n "$BASE_NORM" ] && [ "$(to_lower "$BASE_NORM")" = "$TARGET_LOWER" ]; then
      FALLBACK_IFACE="$IF_BASE"
      FALLBACK_LABEL="$BASE_NORM -> $IF_BASE"
      FALLBACK_COUNT=1
    fi
  fi

  for slot in 1 2 3 4 5 6 7 8 9; do
    SSID="$(nvram get wl${BAND}.${slot}_ssid 2>/dev/null)"
    IFN="$(nvram get wl${BAND}.${slot}_ifname 2>/dev/null)"
    IFN=$(normalize_iface "$IFN")
    [ -n "$IFN" ] || continue
    SSID_NORM=$(normalize_ssid "$SSID")
    if [ "$SSID_NORM" = "$TARGET_NORM" ]; then
      echo "$IFN"
      return 0
    fi
    if [ -n "$SSID_NORM" ] && [ "$(to_lower "$SSID_NORM")" = "$TARGET_LOWER" ]; then
      if [ "$FALLBACK_COUNT" -eq 0 ]; then
        FALLBACK_IFACE="$IFN"
        FALLBACK_LABEL="$SSID_NORM -> $IFN"
      else
        FALLBACK_LABEL="$FALLBACK_LABEL, $SSID_NORM -> $IFN"
      fi
      FALLBACK_COUNT=$((FALLBACK_COUNT + 1))
    fi
  done

  if [ "$FALLBACK_COUNT" -eq 1 ]; then
    warn -c cli,vlan "Case-insensitive match for '$TARGET_NORM' -> $FALLBACK_IFACE"
    echo "$FALLBACK_IFACE"
    return 0
  fi

  if [ "$FALLBACK_COUNT" -gt 1 ]; then
    warn -c cli,vlan "Ambiguous case-insensitive matches for '$TARGET_NORM': $FALLBACK_LABEL"
  fi

  return 1
}

# find_if_by_ssid_any — Robust SSID lookup across all bands/slots (fallback)
# Args: $1=ssid_name
# Returns: stdout interface_name(s), newline-delimited, or empty if not found
# Explanation: Scans all NVRAM *_ssid entries and resolves candidate interfaces
#   from nvram without requiring them to be fully alive yet. The caller handles
#   waiting/verification so shared SSIDs across bands are not collapsed to the
#   first radio that happens to be up.
# Use case: Fallback when band/slot unknown, or user moves SSID between bands
find_if_by_ssid_any() {
  ssid="$1"
  TARGET_NORM=$(normalize_ssid "$ssid")
  [ -z "$TARGET_NORM" ] && return 1
  [ "$TARGET_NORM" = "unused-placeholder" ] && return 1
  TARGET_LOWER=$(to_lower "$TARGET_NORM")

  EXACT_MATCHES=""
  EXACT_COUNT=0
  FALLBACK_IFACE=""
  FALLBACK_LABELS=""
  FALLBACK_COUNT=0

  while IFS= read -r entry; do
    case "$entry" in
      wl*_ssid=*)
        key=${entry%%=*}      # e.g. wl0_ssid or wl2.1_ssid
        raw=${entry#*=}       # SSID string
        base=${key%_ssid}     # e.g. wl0 or wl2.1

        case "$base" in
          wl[0-9]*) : ;;
          *) continue ;;
        esac

        iface=$(nvram get "${base}_ifname" 2>/dev/null)
        iface=$(normalize_iface "$iface")
        [ -n "$iface" ] || continue
        is_internal_vap "$iface" && continue

        ssid_norm=$(normalize_ssid "$raw")

        if [ "$ssid_norm" = "$TARGET_NORM" ]; then
          # Collect exact match (don't return early — there may be more bands)
          EXACT_MATCHES="${EXACT_MATCHES}${EXACT_MATCHES:+
}${iface}"
          EXACT_COUNT=$((EXACT_COUNT + 1))
        elif [ -n "$ssid_norm" ] && [ "$(to_lower "$ssid_norm")" = "$TARGET_LOWER" ]; then
          if [ "$FALLBACK_COUNT" -eq 0 ]; then
            FALLBACK_IFACE="$iface"
            FALLBACK_LABELS="$ssid_norm -> $iface"
          else
            FALLBACK_LABELS="$FALLBACK_LABELS, $ssid_norm -> $iface"
          fi
          FALLBACK_COUNT=$((FALLBACK_COUNT + 1))
        fi
        ;;
    esac
  done <<EOF
$(nvram show 2>/dev/null | grep -E '^wl[0-9][0-9]*(\.[0-9]+)?_ssid=')
EOF

  # Return all exact matches (one per line) if any were found
  if [ "$EXACT_COUNT" -ge 1 ]; then
    printf '%s\n' "$EXACT_MATCHES"
    return 0
  fi

  if [ "$FALLBACK_COUNT" -eq 1 ]; then
    warn -c cli,vlan "Case-insensitive match for '$TARGET_NORM' -> $FALLBACK_IFACE"
    echo "$FALLBACK_IFACE"
    return 0
  fi

  if [ "$FALLBACK_COUNT" -gt 1 ]; then
    warn -c cli,vlan "Ambiguous case-insensitive matches for '$TARGET_NORM': $FALLBACK_LABELS"
  fi

  return 1
}

# ========================================================================== #
# BOOT SSID READINESS GATE — Wait for configured SSIDs during boot mode      #
# ========================================================================== #

# ssid_in_nvram — Check if an SSID exists anywhere in nvram
# Args: $1=ssid_name
# Returns: 0 if found, 1 if not found
ssid_in_nvram() {
  _needle="$1"
  [ -n "$_needle" ] || return 1
  # Cache nvram output for efficiency (only fetch once)
  [ -n "${_NVRAM_SSID_CACHE:-}" ] || _NVRAM_SSID_CACHE="$(nvram show 2>/dev/null | grep '_ssid=')"
  printf '%s\n' "$_NVRAM_SSID_CACHE" | grep -Fq "_ssid=$_needle"
}

# boot_wait_for_configured_ssids — Block until configured SSIDs are ready (boot mode only)
# Args: $1=timeout_seconds (default 30)
# Returns: 0 always (logs warnings on timeout/missing SSIDs, continues anyway)
# Purpose: Reduce boot race conditions by waiting for WLAN interfaces to appear
boot_wait_for_configured_ssids() {
  [ "$MERV_MANAGER_MODE" = "boot" ] || return 0

  timeout="${1:-30}"
  case "$timeout" in ''|*[!0-9]*) timeout=30 ;; esac

  # Build list of configured SSIDs from settings.json (filtered by node assignment)
  cfg=""
  i=1
  while [ "$i" -le "${MAX_SSIDS:-12}" ]; do
    ssid="$(get_ssid_slot_value "$i" "$SETTINGS_FILE")"
    # Check for fatal filter condition (hardware profile not ready)
    if [ "${SSID_FILTER_FATAL:-0}" = "1" ]; then
      error -c cli,vlan "Boot SSID wait: aborting due to SSID filter fatal condition (MAX_SSIDS not set)"
      return 1
    fi
    [ -z "$ssid" ] && ssid="unused-placeholder"
    if [ "$ssid" != "unused-placeholder" ]; then
      cfg="${cfg}
$i|$ssid"
    fi
    i=$((i+1))
  done
  cfg="$(printf '%s\n' "$cfg" | sed '/^$/d')"

  [ -n "$cfg" ] || {
    info -c cli,vlan "Boot SSID wait: no SSIDs configured"
    return 0
  }

  info -c cli,vlan "Boot SSID wait: validating configured SSIDs vs nvram, then waiting up to ${timeout}s for interfaces..."

  # Partition SSIDs: in nvram (wait for interface) vs missing (likely typo)
  missing_nvram=""
  waitlist=""
  while IFS='|' read -r idx ssid; do
    [ -n "$idx" ] || continue
    if ssid_in_nvram "$ssid"; then
      waitlist="${waitlist}
$idx|$ssid"
    else
      missing_nvram="${missing_nvram}
SSID_$(printf '%02d' "$idx")='$ssid'"
    fi
  done <<EOF
$cfg
EOF

  if [ -n "$missing_nvram" ]; then
    warn -c cli,vlan "Boot SSID wait: SSID(s) not found in nvram (likely typo or not configured in Wireless GUI):"
    printf '%s\n' "$missing_nvram" | sed '/^$/d' | while IFS= read -r line; do
      warn -c cli,vlan "  $line"
    done
  fi

  waitlist="$(printf '%s\n' "$waitlist" | sed '/^$/d')"
  [ -n "$waitlist" ] || return 0

  start="$(date +%s 2>/dev/null || echo 0)"
  case "$start" in ''|*[!0-9]*) start=1 ;; esac

  # Wait until all SSIDs in waitlist resolve to present interfaces, or timeout
  pending="$waitlist"
  ready_count=0
  total_count="$(printf '%s\n' "$waitlist" | wc -l | tr -d ' ')"

  while :; do
    new_pending=""

    while IFS='|' read -r idx ssid; do
      [ -n "$idx" ] || continue

      # find_if_by_ssid_any may return multiple lines (dual-band identical SSIDs)
      # Mark ready if ANY of the resolved interfaces is present in the kernel
      _resolved="$(find_if_by_ssid_any "$ssid")"
      _ssid_ready=0
      if [ -n "$_resolved" ]; then
        while IFS= read -r _boot_ifn; do
          [ -n "$_boot_ifn" ] || continue
          iface_exists "$_boot_ifn" && { _ssid_ready=1; break; }
        done <<_BWAIT_EOF_
$_resolved
_BWAIT_EOF_
      fi
      if [ "$_ssid_ready" = "1" ]; then
        ready_count=$((ready_count + 1))
      else
        new_pending="${new_pending}
$idx|$ssid"
      fi
    done <<EOF
$pending
EOF

    pending="$(printf '%s\n' "$new_pending" | sed '/^$/d')"
    [ -z "$pending" ] && {
      info -c cli,vlan "Boot SSID wait: all $total_count configured SSID interfaces are present"
      return 0
    }

    now="$(date +%s 2>/dev/null || echo 0)"
    case "$now" in ''|*[!0-9]*) now=$((start + timeout + 1)) ;; esac

    if [ $((now - start)) -ge "$timeout" ]; then
      warn -c cli,vlan "Boot SSID wait: timed out after ${timeout}s ($ready_count/$total_count ready)"
      warn -c cli,vlan "Boot SSID wait: still missing interface(s) for:"
      printf '%s\n' "$pending" | while IFS='|' read -r idx ssid; do
        [ -n "$idx" ] || continue
        warn -c cli,vlan "  SSID_$(printf '%02d' "$idx")='$ssid'"
      done
      return 0
    fi

    sleep 1
  done
}

# ========================================================================== #
# AP ISOLATION & SSID BINDING — Wireless policy and bridge attachment        #
# ========================================================================== #

# set_ap_isolation — Enable/disable AP isolation (privacy between clients on same SSID)
# Args: $1=interface, $2=value (0=off, 1=on)
# Returns: none (logs errors on failure, continues)
# Explanation: Uses wl command for immediate effect; persists via NVRAM if requested
nvram_base_for_ifname() {
  local ifn line key val base
  ifn="$1"
  [ -n "$ifn" ] || return 1

  while IFS= read -r line; do
    key=${line%%=*}
    val=${line#*=}
    [ "$val" = "$ifn" ] || continue
    base=${key%_ifname}
    echo "$base"
    return 0
  done <<EOF
$(nvram show 2>/dev/null | grep -E '^wl[0-9][0-9]*(\.[0-9]+)?_ifname=')
EOF

  return 1
}

set_ap_isolation() {
  IFN="$1"; VAL="$2"  # 0 or 1
  case "$VAL" in
    0|1)
      if [ "$DRY_RUN" = "yes" ]; then
        echo "[DRY-RUN] wl -i $IFN ap_isolate $VAL"
      else
        # Apply AP isolation immediately on interface
        wl -i "$IFN" ap_isolate "$VAL" 2>/dev/null || {
          error -c cli,vlan "Failed to set AP isolation=$VAL for $IFN"
          return 1
        }
        info -c cli,vlan "Set AP isolation=$VAL for $IFN"
        # Persist in NVRAM for specific bands/slots (wl0, wl0.1, etc.)
        if [ "$PERSISTENT" = "yes" ]; then
          base="$(nvram_base_for_ifname "$IFN")"
          if [ -n "$base" ]; then
            nvram set "${base}_ap_isolate=$VAL"
            nvram commit
          else
            warn -c cli,vlan "Persistent AP isolation: could not map ifname '$IFN' to nvram wl base; skipping nvram set"
          fi
        fi
        track_change "Set AP isolation=$VAL for $IFN"
      fi
      ;;
  esac
}

# bind_configured_ssids — Dynamically bind all configured SSIDs to VLAN bridges
# Args: none (reads SETTINGS_FILE)
# Returns: none (logs all actions)
# Explanation: SSID_01-SSID_MAX_SSIDS, each with corresponding VLAN_01-VLAN_MAX_SSIDS
# Initial pass is immediate; the post-restart second pass acts as the VAP safety net.
# Also restores unconfigured SSIDs to br0 (prevents orphaning on VLAN changes)
bind_configured_ssids() {
  # Pre-scan: build the list of configured + filter-allowed slot numbers in a
  # single pass. The bind loop below iterates only this list, avoiding the
  # double JSON read (get_ssid_slot_value + get_vlan_slot_value) for empty or
  # filter-denied slots on every apply. On a 12-slot config with 3 populated
  # SSIDs this skips ~18 sed scans per pass (called twice per apply).
  _filter_allowed=""
  _filter_denied=""
  _configured_slots=""
  _fi=1
  while [ "$_fi" -le "$MAX_SSIDS" ]; do
    if is_ssid_slot_allowed "$_fi" "$SETTINGS_FILE"; then
      _fs=$(get_ssid_slot_value "$_fi" "$SETTINGS_FILE")
      if [ -n "$_fs" ] && [ "$_fs" != "unused-placeholder" ]; then
        _filter_allowed="${_filter_allowed} $(printf '%02d' "$_fi"):${_fs}"
        _configured_slots="${_configured_slots} $_fi"
      fi
    else
      _filter_denied="${_filter_denied} $(printf '%02d' "$_fi")"
    fi
    _fi=$((_fi+1))
  done
  if [ -n "$_filter_allowed" ]; then
    info -c cli,vlan "SSID filter [${_SSID_FILTER_TOKEN}] active:${_filter_allowed}"
  else
    info -c cli,vlan "SSID filter [${_SSID_FILTER_TOKEN}]: no active SSIDs for this node"
  fi
  [ -z "$_filter_denied" ] || info -c vlan "SSID filter [${_SSID_FILTER_TOKEN}] denied slots:${_filter_denied}"

  # Fatal-filter check: the pre-scan above already invoked get_ssid_slot_value
  # for slot 1, so SSID_FILTER_FATAL is set (or not) by the time we reach here.
  if [ "${SSID_FILTER_FATAL:-0}" = "1" ]; then
    error -c cli,vlan "bind_configured_ssids: aborting due to SSID filter fatal condition"
    return 1
  fi

  # Bind loop: only configured + allowed slots. Unused/denied slots are not
  # re-read and no longer emit a per-slot "skipped" log line — the pre-scan
  # summary above already covers them.
  for i in $_configured_slots; do
    ssid=$(get_ssid_slot_value "$i" "$SETTINGS_FILE")
    vlan=$(get_vlan_slot_value "$i" "$SETTINGS_FILE")
    # Apply defaults: empty VLAN = untagged (none). Empty SSID is impossible
    # here because the pre-scan filters those out, but keep the guard for
    # robustness against race conditions on settings.json.
    [ -z "$ssid" ] || [ "$ssid" = "unused-placeholder" ] && continue
    [ -z "$vlan" ] && vlan="none"

    validate_vlan_id "$vlan" || continue
    # Find ALL interfaces for this SSID (handles dual-band identical SSIDs)
    IFN="$(find_if_by_ssid_any "$ssid")"
    if [ -n "$IFN" ]; then
      while IFS= read -r _ifn; do
        [ -n "$_ifn" ] || continue
        info -c cli,vlan "Resolved SSID '$ssid' -> $_ifn"
        # Mark as managed before waiting — prevents the br0 sweep from
        # catching a slower-starting band if wait_for_interface times out
        note_bound_iface "$_ifn"
        if ! wait_for_interface "$_ifn"; then
          warn -c cli,vlan "$_ifn did not appear within timeout"
          continue
        fi
        # Native Radio Safeguard: wl0/wl1 moved to VLAN bridges can break
        # Broadcom firmware routing. Fall back to untagged unless overridden.
        if is_native_radio "$_ifn" && [ "$vlan" != "none" ] && [ "$ENABLE_NATIVE_SSID" != "1" ]; then
          warn -c cli,vlan "Refusing to tag native radio $_ifn with VLAN $vlan. Firmware may reject this."
          info -c cli,vlan "Use Guest Networks instead, or force via ENABLE_NATIVE_SSID=1. Falling back to untagged."
          attach_to_bridge "$_ifn" "none" "SSID_$(printf "%02d" $i) (Native Radio Fallback)"
          continue
        fi
        attach_to_bridge "$_ifn" "$vlan" "SSID_$(printf "%02d" $i)"
      done <<_SSID_EOF_
$IFN
_SSID_EOF_
    else
      warn -c cli,vlan "SSID_$(printf "%02d" $i) '$ssid' not found on any band"
    fi
  done

  BOUND_SET=" $BOUND_IFACES "
  for iface in $(nvram show 2>/dev/null | grep -E '^wl[0-9][0-9]*(\.[0-9]+)?_ifname=' | awk -F= '{print $2}' | sort -u); do
        iface=$(normalize_iface "$iface")
        [ -n "$iface" ] || continue
        iface_exists "$iface" || continue
        is_internal_vap "$iface" && continue
        is_wl_iface "$iface" || continue

        case "$BOUND_SET" in
          *" $iface "*) continue ;;
        esac

        attach_to_bridge "$iface" "none" "Unconfigured IF $iface"
      done
}

# --------------------------
# Band resolution
# --------------------------
resolve_and_attach() {
  BAND="$1"
  SSID="$2"
  VLAN="$3"
  LABEL="$4"

  validate_vlan_id "$VLAN"

  if [ -z "$SSID" ] || [ "$SSID" = "unused-placeholder" ]; then
    info -c cli,vlan "$LABEL skipped"
    return
  fi

  IFN=""
  # Try up to 5 times to allow interfaces to appear
  for _ in 1 2 3 4 5; do
    if [ "$BAND" = "auto" ] || [ "$BAND" = "any" ] || [ -z "$BAND" ]; then
      IFN="$(find_if_by_ssid_any "$SSID")"
    else
      IFN="$(find_if_by_ssid "$BAND" "$SSID")"
    fi
    [ -n "$IFN" ] && break
    sleep 1
  done

  if [ -z "$IFN" ]; then
    if [ "$BAND" = "auto" ] || [ "$BAND" = "any" ] || [ -z "$BAND" ]; then
      warn -c cli,vlan "$LABEL SSID '$SSID' not found on any band"
    else
      warn -c cli,vlan "$LABEL SSID '$SSID' not found on band $BAND"
    fi
    return
  fi

  while IFS= read -r _ifn; do
    [ -n "$_ifn" ] || continue
    # Native Radio Safeguard: wl0/wl1 moved to VLAN bridges can break
    # Broadcom firmware routing. Fall back to untagged unless overridden.
    if is_native_radio "$_ifn" && [ "$VLAN" != "none" ] && [ "$ENABLE_NATIVE_SSID" != "1" ]; then
      warn -c cli,vlan "Refusing to tag native radio $_ifn with VLAN $VLAN. Firmware may reject this."
      attach_to_bridge "$_ifn" "none" "$LABEL ($SSID - Native Fallback)"
      continue
    fi
    attach_to_bridge "$_ifn" "$VLAN" "$LABEL ($SSID)"
  done <<_RAA_EOF_
$IFN
_RAA_EOF_
}

# --------------------------
# Configuration Summary
# --------------------------
show_configuration_summary() {
  info -c cli,vlan "=== CONFIGURATION SUMMARY ==="
  
  # Display current bridge topology from brctl
  info -c cli,vlan "Current bridge status:"
  brctl show 2>/dev/null | while IFS= read -r line; do
    info -c cli,vlan "  $line"
  done

  if [ "$TRUNK_APPLIED" -eq 1 ]; then
    info -c cli,vlan "Trunk summary: trunk script applied successfully"
  elif detect_trunks_configured; then
    info -c cli,vlan "Trunk summary: trunk config detected but script was not applied"
  fi

  release_script_lock
  if [ "$DRY_RUN" = "yes" ]; then
    # Dry-run mode: remind user no changes were made
    info -c cli,vlan "=== DRY-RUN COMPLETE ==="
    info -c cli,vlan "No changes were applied to the system"
    info -c cli,vlan "To apply changes, set DRY_RUN=no in settings.json"
  else
    # Live mode: confirm configuration was applied
    info -c cli,vlan "=== CONFIGURATION APPLIED ==="
  fi
}

# ========================================================================== #
# CLEANUP & SERVICE RESTART — Remove old config, restart affected services   #
# ========================================================================== #

# ebt_cleanup_all_trunk_rules — Remove all MerVLAN ebtables trunk chains/jumps
# Must run before any bridge/VLAN changes to prevent stale ebtables rules from
# blocking traffic after config changes. Safe to call even if ebtables is absent
# or no MerVLAN rules exist.
ebt_cleanup_all_trunk_rules() {
  # Skip if ebtables binary is not available
  type ebtables >/dev/null 2>&1 || return 0

  local port chain proto="802_1Q" idx=0

  if [ "$DRY_RUN" = "yes" ]; then
    info -c cli,vlan "[DRY-RUN] would clean up ebtables trunk rules for eth0-eth9"
    return 0
  fi

  info -c cli,vlan "Cleaning up stale ebtables trunk rules..."

  # Enumerate eth0-eth9 (covers all supported trunk ports)
  while [ $idx -le 9 ]; do
    port="eth${idx}"
    chain="MERV_TRUNK_${port}"

    # Delete ingress jump rules from FORWARD
    while ebtables -t filter -D FORWARD -p "$proto" -i "$port" -j "$chain" 2>/dev/null; do :; done
    # Delete egress jump rules from FORWARD
    while ebtables -t filter -D FORWARD -p "$proto" -o "$port" -j "$chain" 2>/dev/null; do :; done
    # Flush and delete the per-port chain (ignore errors if nonexistent)
    ebtables -t filter -F "$chain" 2>/dev/null
    ebtables -t filter -X "$chain" 2>/dev/null

    idx=$((idx + 1))
  done

  # Clean up plan file directory from previous runs
  rm -f /tmp/mervlan_tmp/ebtables/trunk.rules 2>/dev/null || :
}

# ==========================================================================
# MERV_QT — L2 quarantine chain (ebtables filter table)
# ==========================================================================
# A dedicated chain that FORWARD and INPUT both jump to. Each managed wl*.*
# gets one DROP rule scoped to --logical-in br0: fires only while the
# interface is a br0 member, dormant once moved to a VLAN bridge. No
# per-interface cleanup needed for VLAN-bound ports. Only interfaces
# intentionally placed in br0 (unmanaged SSIDs, fallbacks) require an
# explicit ebt_quarantine_release in attach_to_bridge's none) case.
# ==========================================================================
MERV_QT_CHAIN="MERV_QT"
MERV_DHCP_HOLD_CHAIN="MERV_DHCP_HOLD"

# ebt_quarantine_init — Create MERV_QT chain and insert FORWARD/INPUT jumps.
# Idempotent: uses grep on -L output to avoid duplicate jump rules.
ebt_quarantine_init() {
  type ebtables >/dev/null 2>&1 || return 0
  [ "$DRY_RUN" = "yes" ] && return 0
  ebtables -t filter -N "$MERV_QT_CHAIN" 2>/dev/null || true
  ebtables -t filter -L FORWARD 2>/dev/null | grep -qF "$MERV_QT_CHAIN" || \
    ebtables -t filter -I FORWARD -j "$MERV_QT_CHAIN" 2>/dev/null || true
  ebtables -t filter -L INPUT 2>/dev/null | grep -qF "$MERV_QT_CHAIN" || \
    ebtables -t filter -I INPUT -j "$MERV_QT_CHAIN" 2>/dev/null || true
}

# ebt_quarantine_add — Add a per-interface DROP rule scoped to --logical-in br0.
# Args: $1=interface_name
# One rule covers both FORWARD and INPUT (both chains jump to MERV_QT).
# If --logical-in is unsupported, the add fails silently (2>/dev/null) and
# the system degrades to evict-only behavior via heal_event.sh.
ebt_quarantine_add() {
  local _if="$1"
  local _qt_rules
  [ -n "$_if" ] || return 0
  type ebtables >/dev/null 2>&1 || return 0
  if [ "$DRY_RUN" = "yes" ]; then
    info -c cli,vlan "[DRY-RUN] MERV_QT: would quarantine $_if in br0"
    return 0
  fi

  _qt_rules=$(ebtables -t filter -L "$MERV_QT_CHAIN" 2>/dev/null)
  if printf '%s\n' "$_qt_rules" | grep -qF -- "-i $_if" && \
     printf '%s\n' "$_qt_rules" | grep -qF -- "logical-in br0"; then
    return 0
  fi

  ebtables -t filter -A "$MERV_QT_CHAIN" -i "$_if" --logical-in br0 -j DROP 2>/dev/null || true
}

ebt_quarantine_ensure_expected_rules() {
  local _if _vid _pairs

  type ebtables >/dev/null 2>&1 || return 0
  [ "$DRY_RUN" = "yes" ] && return 0

  ebt_quarantine_init
  if type merv_iface_vid_list >/dev/null 2>&1; then
    _pairs=$(merv_iface_vid_list)
  else
    _pairs=$(merv_mac_build_expected_iface_vid 2>/dev/null)
  fi
  printf '%s\n' "$_pairs" | while IFS=' ' read -r _if _vid; do
    [ -n "$_if" ] && [ -n "$_vid" ] || continue
    # Only quarantine VLAN-bound interfaces (real VID >= 2, purely numeric).
    # Intentionally-native/br0 interfaces (none, trunk, 0, 1) are excluded.
    # *[!0-9]* catches malformed resolver output (e.g. "187,188", "vlan187").
    case "$_vid" in
      ''|none|trunk|0|1|*[!0-9]*) continue ;;
    esac
    [ "$_vid" -ge 2 ] 2>/dev/null || continue
    ebt_quarantine_add "$_if"
  done
}

# ebt_quarantine_release — Remove the quarantine rule for a specific interface.
# Args: $1=interface_name
# Called ONLY from attach_to_bridge none) after successful brctl addif br0.
# Required for interfaces intentionally placed in br0. VLAN-bound interfaces
# never need this — their rules go dormant via --logical-in br0 automatically.
ebt_quarantine_release() {
  local _if="$1"
  [ -n "$_if" ] || return 0
  type ebtables >/dev/null 2>&1 || return 0
  [ "$DRY_RUN" = "yes" ] && return 0
  ebtables -t filter -D "$MERV_QT_CHAIN" -i "$_if" --logical-in br0 -j DROP 2>/dev/null || true
  info -c cli,vlan "MERV_QT: released quarantine for $_if (correctly in $DEFAULT_BRIDGE)"
}

# ebt_quarantine_teardown — Full MERV_QT chain teardown.
# Strict ebtables order: flush rules → delete jump refs → delete chain.
# Also inlined in mervlan_boot.sh setupdisable/nodedisable (no sourcing there).
ebt_quarantine_teardown() {
  type ebtables >/dev/null 2>&1 || return 0
  ebtables -t filter -F "$MERV_QT_CHAIN" 2>/dev/null || true
  ebtables -t filter -D FORWARD -j "$MERV_QT_CHAIN" 2>/dev/null || true
  ebtables -t filter -D INPUT   -j "$MERV_QT_CHAIN" 2>/dev/null || true
  ebtables -t filter -X "$MERV_QT_CHAIN" 2>/dev/null || true
}

# cleanup_existing_config — Remove VLAN infrastructure from previous runs
# Args: none
# Returns: none (logs all actions)
# Explanation: Removes all VLAN bridges (br1+) and VLAN interfaces (eth0.VID+)
# Preserves br0 (default LAN bridge)
cleanup_existing_config() {
  info -c cli,vlan "Cleaning up existing VLAN config..."

  # --- MERV_QT: arm L2 quarantine BEFORE touching any bridge ---------------
  # Keep MERV_QT additive/idempotent so we never create an empty-chain gap.
  # Ensure chain/jumps exist and expected DROP rules are present for every
  # MERVLAN-managed interface.
  # Add a DROP rule (scoped to --logical-in br0) for every MERVLAN-managed
  # wl*.* derived from settings + NVRAM. Any managed VAP that lands in br0
  # during a mid-cycle restart_wireless event is immediately dark at L2: no
  # DHCP, no ARP, no static-IP traffic. Rules go dormant automatically once
  # each interface is correctly placed in its VLAN bridge — zero per-interface
  # cleanup needed. Only MERVLAN-managed interfaces are quarantined; firmware-
  # owned subinterfaces (e.g. AiMesh management SSIDs like wl0.1 on nodes)
  # are excluded so they can continue handling AiMesh provisioning traffic.
  ebt_quarantine_ensure_expected_rules
  _qt_count=0
  if type merv_iface_vid_list >/dev/null 2>&1; then
    _qt_ifaces=$(merv_iface_vid_list | awk '{print $1}')
  else
    _qt_ifaces=$(merv_mac_build_expected_iface_vid 2>/dev/null | awk '{print $1}')
  fi
  for _qt_if in $_qt_ifaces; do
    [ -n "$_qt_if" ] || continue
    _qt_count=$((_qt_count + 1))
  done
  [ "$DRY_RUN" != "yes" ] && [ "$_qt_count" -gt 0 ] && \
    info -c cli,vlan "MERV_QT: quarantine armed for $_qt_count wl*.* interface(s)"

  # Arm MERV_MAC secondary shield from last-known db (init-only on first run).
  # ebt_mac_shield_init_and_apply is idempotent: safe to call on every apply.
  ebt_mac_shield_init_and_apply "$(merv_mac_best_db 2>/dev/null || true)"

  # --- ebtables: remove all MerVLAN trunk filter rules FIRST ---
  # Must run before bridge/VLAN teardown to prevent stale rules that reference
  # chains on interfaces we are about to delete.
  ebt_cleanup_all_trunk_rules

  # Remove VLAN bridges (except br0 - the default LAN bridge)
  # Iterate through all bridges, remove those numbered br1+ (custom VLANs)
  for br in $(brctl show 2>/dev/null | awk 'NR>1 {print $1}' | grep -E '^br[1-9][0-9]*$'); do
    if [ "$DRY_RUN" = "yes" ]; then
      echo "[DRY-RUN] detach all ports from $br; ip link set $br down; brctl delbr $br"
    else
      # Detach any member interfaces so delbr succeeds
      # Reuse lib_stp's robust sysfs-first + brctl-fallback enumerator
      for port in $(stp_list_bridge_members "$br"); do
        brctl delif "$br" "$port" 2>/dev/null
      done
      # Bring bridge down before deletion
      ip link set "$br" down 2>/dev/null
      # Remove bridge interface
      brctl delbr "$br" 2>/dev/null
      info -c cli,vlan "Removed bridge $br"
      track_change "Removed bridge $br"
    fi
  done

  # Remove VLAN interfaces (eth0.100, eth0.200, etc.)
  # Parse ip link output for VLAN sub-interfaces (format: "eth0.100@eth0")
  ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | grep -E "^${UPLINK_PORT}\\.[0-9]+(@|$)" | cut -d'@' -f1 | while read -r vif; do
    if [ "$DRY_RUN" = "yes" ]; then
      echo "[DRY-RUN] ip link del $vif"
    else
      # Delete VLAN interface
      ip link del "$vif" 2>/dev/null
      info -c cli,vlan "Removed VLAN interface $vif"
      track_change "Removed VLAN interface $vif"
    fi
  done
}

# --- rc/queue helpers --------------------------------------------------------

rc_queue_has() {
  # true if rc has a pending/active matching token in the queue file
  pattern="$1"
  [ -n "$pattern" ] || return 1
  [ -f /tmp/rc_service ] || return 1
  grep -E "$pattern" /tmp/rc_service 2>/dev/null | grep -qv '^$'
}

rc_proc_busy() {
  # best-effort: see if a service/rc job referencing our token is running
  # Tokens intentionally allow partial matches (e.g., "switch") so compound
  # subcommands like "switch restart" are still detected in process args.
  pattern="$1"
  [ -n "$pattern" ] || return 1
  ps w 2>/dev/null | grep -E "[s]ervice" | grep -E "$pattern" >/dev/null 2>&1
}

# Token lease and neutral enforcement APIs live in settings/lib_mervqt.sh so
# manager, compatibility callers, tests, and reconciliation share one engine.

merv_native_auth_snapshot() {
  local _auth_file _ridx _radio _key _nv _indexes
  _auth_file="$LOCKDIR/native_auth.snapshot.$$"
  : > "$_auth_file"

  # Use live radio index enumeration so quad-band (wl3) and future radios
  # are included.  Fall back to the classic trio if nvram probe finds nothing.
  _indexes=$(merv_list_wl_radio_indexes)
  : "${_indexes:=0 1 2}"

  for _ridx in ${_indexes}; do
    _radio="wl${_ridx}"
    for _key in ssid auth_mode_x crypto wpa_psk akm; do
      _nv="${_radio}_${_key}"
      printf '%s=%s\n' "$_nv" "$(nvram get "$_nv" 2>/dev/null)" >> "$_auth_file"
    done
  done

  MERV_NATIVE_AUTH_SNAPSHOT="$_auth_file"
  export MERV_NATIVE_AUTH_SNAPSHOT
}

merv_native_auth_audit() {
  local _nv _old _new
  [ -f "${MERV_NATIVE_AUTH_SNAPSHOT:-}" ] || return 0

  while IFS='=' read -r _nv _old; do
    _new="$(nvram get "$_nv" 2>/dev/null)"
    if [ "$_new" != "$_old" ]; then
      warn -c cli,vlan "Native auth changed during manager: $_nv"
    fi
  done < "$MERV_NATIVE_AUTH_SNAPSHOT"

  rm -f "$MERV_NATIVE_AUTH_SNAPSHOT" 2>/dev/null || true
}

merv_manager_final_security_check() {
  local bad iface vid pairs i ssid vlan have_vlan_ssid

  bad=0
  have_vlan_ssid=0

  if ! merv_dhcp_hold_rules_present; then
    error -c cli,vlan "SECURITY FAIL: token owner exists but exact DHCP-hold rules are incomplete"
    bad=1
  fi

  # The bridge placement checks below are not sufficient on their own: a
  # successful apply must also prove that both owner chains, both parent
  # jumps, and every exact DROP rule match the expected state.  Any missing,
  # duplicated, or extra rule is a security failure.
  if type merv_l2_guard_verify_exact >/dev/null 2>&1; then
    if ! merv_l2_guard_verify_exact; then
      error -c cli,vlan "SECURITY FAIL: exact L2 guard-chain verification failed"
      bad=1
    fi
  else
    error -c cli,vlan "SECURITY FAIL: L2 guard verifier unavailable"
    bad=1
  fi

  i=1
  while [ "$i" -le "$MAX_SSIDS" ]; do
    ssid=$(get_ssid_slot_value "$i" "$SETTINGS_FILE")
    vlan=$(get_vlan_slot_value "$i" "$SETTINGS_FILE")
    case "$vlan" in
      ''|none|trunk) ;;
      *[!0-9]*) ;;
      *)
        if [ "$vlan" -ge 2 ] && [ "$vlan" -le 4094 ] && [ -n "$ssid" ] && [ "$ssid" != "unused-placeholder" ]; then
          have_vlan_ssid=1
          break
        fi
        ;;
    esac
    i=$((i + 1))
  done

  pairs=$(merv_mac_build_expected_iface_vid 2>/dev/null)
  if [ -z "$pairs" ]; then
    if [ "$have_vlan_ssid" -eq 1 ]; then
      error -c cli,vlan "SECURITY FAIL: no expected managed VAP list available"
      return 1
    fi
    [ "$bad" -eq 0 ]
    return $?
  fi

  while IFS=' ' read -r iface vid; do
    [ -n "$iface" ] && [ -n "$vid" ] || continue

    if [ -e "/sys/class/net/br0/brif/$iface" ]; then
      error -c cli,vlan "SECURITY FAIL: managed VAP $iface is still in br0 after manager"
      bad=1
    fi

    if [ ! -e "/sys/class/net/br${vid}/brif/$iface" ]; then
      error -c cli,vlan "SECURITY FAIL: managed VAP $iface is not in expected br${vid}"
      bad=1
    fi
  done <<_PAIRS_
$pairs
_PAIRS_

  [ "$bad" -eq 0 ]
}

run_service_with_timeout() {
  # $1 = literal 'service' subcommand string (e.g., 'restart_wireless' or 'switch restart')
  # $2 = timeout seconds
  cmd_string="$1"
  tmax="${2:-60}"

  [ -n "$cmd_string" ] || return 1

  if [ "$DRY_RUN" = "yes" ]; then
    info -c cli,vlan "[DRY-RUN] service $cmd_string"
    return 0
  fi

  set -- $cmd_string
  /sbin/service "$@" 2>/dev/null &
  spid=$!

  elapsed=0
  while kill -0 "$spid" 2>/dev/null; do
    # restart_wireless / wlconf / switch restart can flush ebtables WHILE the
    # service process is still alive. Restoring only the DHCP hold here would
    # leave MERV_QT and MERV_MAC missing for the whole restart (30-90s) — an
    # open L2 escape window for ARP/static-IP traffic, not just DHCP. Restore
    # every guard layer each second (all fast-path to no-ops when intact).
    merv_guard_tick

    if [ "$elapsed" -ge "$tmax" ]; then
      warn -c cli,vlan "service $cmd_string exceeded ${tmax}s; continuing without waiting"
      return 124
    fi
    sleep 1
    elapsed=$((elapsed + 1))
  done

  rc=0
  wait "$spid" 2>/dev/null || rc=$?
  return $rc
}

safe_service_restart() {
  # $1 = subcommand string, $2 = token(s) to detect in rc queue (ERE), $3 = timeout seconds
  subcmd="$1"
  tokens="${2:-$1}"
  timeout_sec="${3:-60}"

  [ -n "$subcmd" ] || return 1

  if rc_queue_has "$tokens" || rc_proc_busy "$tokens"; then
    warn -c cli,vlan "rc busy with ($tokens); skipping 'service $subcmd'"
    return 0
  fi

  run_service_with_timeout "$subcmd" "$timeout_sec"
}

wait_for_rc_quiet() {
  local need max_wait quiet start now

  need="${1:-6}"
  max_wait="${2:-30}"
  quiet=0
  start=$(date +%s)

  info -c vlan "wait_for_rc_quiet: watching rc (need=${need}s quiet, max=${max_wait}s)"

  # Enforce expected MERV_QT rules once before the tick loop — ebt_quarantine_ensure_expected_rules
  # calls merv_mac_build_expected_iface_vid (expensive). Per-tick calls multiply that cost
  # across every sleep interval. The per-tick guard tick below handles cheap chain repair.
  ebt_quarantine_ensure_expected_rules
  while :; do
    # Re-arm ALL L2 shields on every tick — rc's restart_wireless wipes ebtables,
    # so MERV_QT, MERV_MAC and the DHCP hold all need active re-arming while wl
    # interfaces sit in br0. merv_guard_tick reads the ebtables table once and
    # repairs each layer; every path fast-paths to a no-op when intact, and only
    # rebuilds expected DROP rules if a chain was fully wiped.
    #
    # During rc/wlconf we restore shields only. Do NOT brctl-delif VAPs here;
    # that fights Broadcom restart handling and lengthens restart_wireless.
    merv_guard_tick

    if rc_queue_has 'restart_wireless|start_lan|stop_lan|switch|httpd' || \
       rc_proc_busy  'restart_wireless|wlconf|start_lan|switch|httpd'; then
      quiet=0
    else
      quiet=$((quiet + 1))
      [ "$quiet" -ge "$need" ] && {
        info -c vlan "wait_for_rc_quiet: rc quiet for ${quiet}s; proceeding"
        return 0
      }
    fi

    now=$(date +%s)
    if [ $((now - start)) -ge "$max_wait" ]; then
      if rc_queue_has 'restart_wireless|start_lan|stop_lan|switch|httpd' || \
         rc_proc_busy  'restart_wireless|wlconf|start_lan|switch|httpd'; then
        warn -c vlan "wait_for_rc_quiet: timeout after ${max_wait}s while rc remains active; retaining DHCP protection"
        return 1
      fi
      warn -c vlan "wait_for_rc_quiet: timeout after ${max_wait}s with rc idle; continuing to stable verification"
      return 0
    fi

    sleep 1
  done
}

# restart_services — Restart WiFi, bridge, and web server after configuration
# Args: none
# Returns: none (logs all actions)
# Explanation: Restarts wireless to pick up new VAP configuration, then resets
# bridge and HTTP services. Handles optional eapd (EAP daemon) if present.
is_ap_mode() {
  [ "$(nvram get sw_mode 2>/dev/null)" = "3" ]
}

restart_services() {
  info -c cli,vlan "Restarting WiFi & bridge services..."
  # Skip if dry-run mode
  [ "$DRY_RUN" = "yes" ] && return

  # Runtime NVRAM scrub is experimental.
  # It uses live "nvram set" only (no commit), but services still read live
  # NVRAM during switch/wireless restarts. Default is disabled.
  # Enable manually for testing with: MERV_BR0_GUARD_SCRUB=1
  if [ "${MERV_BR0_GUARD_SCRUB:-0}" = "1" ]; then
    type merv_scrub_br0_nvram_ifnames >/dev/null 2>&1 && \
      merv_scrub_br0_nvram_ifnames "manager-pre-restart"
  else
    info -c vlan "BR0 guard[manager-pre-restart]: runtime NVRAM scrub disabled by default"
  fi

  # Bridge-only sweep before service restart begins.
  type merv_soft_evict_wl_from_br0 >/dev/null 2>&1 && \
    merv_soft_evict_wl_from_br0 "manager-pre-restart"

  # Create self-restart marker with expiry timestamp to prevent heal_event.sh from
  # triggering event loops when our service restarts fire service-event callbacks.
  # We write the expiry time (now + window) so heal_event.sh can check: now < expiry.
  SELF_RESTART_MARKER="$LOCKDIR/self_restart.marker"
  SELF_RESTART_WINDOW="${MERV_SELF_RESTART_WINDOW:-45}"
  now=$(date +%s)
  printf '%s\n' $((now + SELF_RESTART_WINDOW)) > "$SELF_RESTART_MARKER" 2>/dev/null || :

  if is_ap_mode; then
    # Prefer a lighter touch in AP mode to avoid rc race conditions
    safe_service_restart "switch restart" "switch" 30
    # REMOVED restart_httpd: causes GUI logouts. User must refresh browser after changes.
    info -c cli,vlan "VLAN changes applied. Refresh your browser to see UI updates."
  else
    safe_service_restart "restart_wireless" "restart_wireless|wireless" 90
    sleep 2
    safe_service_restart "switch restart" "switch" 30
    # REMOVED restart_httpd: causes GUI logouts. User must refresh browser after changes.
    info -c cli,vlan "VLAN changes applied. Refresh your browser to see UI updates."
  fi

  # eapd is intentionally NOT restarted here. restart_wireless already starts
  # eapd with the correct firmware arguments. Calling /usr/sbin/eapd bare
  # (without arguments) after the fact reinitialises native radio auth with
  # empty state on Broadcom platforms and destroys the PSK configuration
  # for wl0/wl1 that restart_wireless just set up correctly.

  # Re-arm DHCP hold immediately on return from rc restarts. The ebtables
  # FORWARD chain was flushed by service restart, leaving a ~4s leak window
  # before wait_for_rc_quiet enters its per-tick restore loop. Any IoT client
  # racing reassociation in that window could pull a br0 lease and end up
  # wedged across the wrong bridge after the watchdog reorganises VAPs.
  type merv_dhcp_hold_enforce >/dev/null 2>&1 && merv_dhcp_hold_enforce

  # Optional per-VAP bounce could be added here when specific VAPs changed.
}

merv_manager_settle_observe() {
  if rc_queue_has 'restart_wireless|start_lan|stop_lan|switch' ||
     rc_proc_busy 'restart_wireless|wlconf|start_lan|switch'; then
    printf '%s\n' 'busy:asus-rc-work'
  elif merv_manager_final_security_check >/dev/null 2>&1; then
    printf '%s\n' healthy
  else
    printf '%s\n' unhealthy
  fi
}

merv_manager_corrective_pass() {
  if [ "$DRY_RUN" = "yes" ]; then
    info -c cli,vlan "watchdog: dry-run mode; skipping verification"
    return 0
  fi
  case "$WATCH_IFACES" in
    "" )
      info -c cli,vlan "watchdog: no interfaces queued; skipping"
      return 0
      ;;
  esac

  merv_dhcp_hold_enforce || {
    error -c cli,vlan "watchdog: DHCP hold enforcement failed"
    return 1
  }
  ebt_quarantine_ensure_expected_rules

  info -c cli,vlan "watchdog: starting verification for: $WATCH_IFACES"
  for pair in $WATCH_IFACES; do
    iface="${pair%,*}"
    vid="${pair#*,}"
    [ -n "$iface" ] || continue
    [ "$vid" = "none" ] && continue
    [ "$vid" = "trunk" ] && continue
    if [ ! -d "/sys/class/net/$iface" ]; then
      info -c cli,vlan "watchdog: ${iface} no longer exists, skipping"
      continue
    fi
    if member_of_bridge "br${vid}" "$iface"; then
      info -c cli,vlan "watchdog: ${iface} already on br${vid}, no action"
    elif member_of_bridge "br0" "$iface"; then
      info -c cli,vlan "watchdog: ${iface} on br0, hard-gating and moving to br${vid}"
      case "$iface" in
        wl*.*|ra*.*|ath*.*)
          wl -i "$iface" down 2>/dev/null || true
          ;;
      esac
      brctl delif br0 "$iface" 2>/dev/null || true
      if ! ensure_vlan_bridge "$vid"; then
        warn -c cli,vlan "watchdog: ensure_vlan_bridge br${vid} failed; cannot move ${iface}"
        continue
      fi
      if brctl addif "br${vid}" "$iface" 2>/dev/null; then
        case "$iface" in
          wl*.*|ra*.*|ath*.*)
            wl -i "$iface" up 2>/dev/null || true
            ;;
        esac
        info -c cli,vlan "watchdog: moved ${iface} -> br${vid}"
      else
        warn -c cli,vlan "watchdog: failed to move ${iface} -> br${vid}"
      fi
    else
      info -c cli,vlan "watchdog: ${iface} not found on br0 or br${vid}"
    fi
  done

  if merv_manager_final_security_check; then
    info -c cli,vlan "watchdog: placement verification passed; manager lease remains active"
  else
    error -c cli,vlan "SECURITY FAIL: watchdog placement verification failed; manager lease remains active"
    return 1
  fi

  info -c cli,vlan "watchdog: verification complete"
  return 0
}

post_rc_watchdog() {
  local _prw_max="${MERV_DHCP_SETTLE_MAX_SEC:-60}"
  [ "$MERV_MANAGER_MODE" != boot ] || _prw_max="${MERV_DHCP_SETTLE_BOOT_MAX_SEC:-150}"
  if merv_dhcp_hold_wait_stable merv_manager_settle_observe \
       merv_manager_corrective_pass "${MERV_DHCP_SETTLE_STABLE_SEC:-3}" "$_prw_max"; then
    info -c cli,vlan "watchdog: consecutive stable security observations passed"
    return 0
  else
    _prw_rc=$?
  fi
  case "$_prw_rc" in
    6) error -c cli,vlan "watchdog: ASUS work remained active at timeout; no corrective bridge pass attempted" ;;
    *) error -c cli,vlan "watchdog: stable security verification failed after bounded corrective pass" ;;
  esac
  return "$_prw_rc"
}

# ========================================================================== #
# MAIN EXECUTION — Orchestrate VLAN configuration application flow           #
# ========================================================================== #

# main — Entry point: validate, cleanup, configure, and verify
# Args: none (reads all global configuration)
# Returns: none (exit code via mervlan_manager.sh script)
main() {
  acquire_script_lock
  merv_action_progress_update prepare 0 1 5 "Preparing VLAN apply..."
  if [ "$DRY_RUN" != "yes" ] && ! merv_observation_wait_idle "${MERV_OBSERVATION_WAIT_SEC:-120}"; then
    error -c cli,vlan "Observation worker did not become idle; aborting before configuration mutation"
    return 1
  fi

  # Lock order is manager/configuration lock -> DHCP state.lock.
  # The token is acquired and exact rules are verified before any mutation.
  if [ "$DRY_RUN" != "yes" ]; then
    MANAGER_RUN_ID="manager-$(date +%s 2>/dev/null || echo 0)-$$"
    if { [ -n "$MANAGER_PARENT_RUN_ID" ] && [ -z "$MANAGER_HANDOFF_ID" ]; } ||
       { [ -z "$MANAGER_PARENT_RUN_ID" ] && [ -n "$MANAGER_HANDOFF_ID" ]; }; then
      error -c cli,vlan "Incomplete DHCP handoff context; both parent run and handoff ID are required"
      return 1
    fi
    [ -z "$MANAGER_PARENT_RUN_ID" ] || merv_dhcp_hold_valid_id "$MANAGER_PARENT_RUN_ID" || {
      error -c cli,vlan "Invalid DHCP handoff parent run ID"
      return 1
    }
    [ -z "$MANAGER_HANDOFF_ID" ] || merv_dhcp_hold_valid_id "$MANAGER_HANDOFF_ID" || {
      error -c cli,vlan "Invalid DHCP handoff ID"
      return 1
    }
    merv_dhcp_hold_reconcile manager-start >/dev/null 2>&1 || :
    if ! merv_dhcp_hold_acquire manager "$MANAGER_RUN_ID" "$MANAGER_PARENT_RUN_ID"; then
      error -c cli,vlan "Cannot establish token-owned DHCP protection; aborting before mutation"
      return 1
    fi
    MANAGER_DHCP_TOKEN="$MERV_DHCP_HOLD_TOKEN"
    if [ -n "$MANAGER_HANDOFF_ID" ]; then
      if ! merv_dhcp_handoff_ack "$MANAGER_HANDOFF_ID" "$MANAGER_PARENT_RUN_ID" "$MANAGER_DHCP_TOKEN"; then
        error -c cli,vlan "Exact DHCP handoff acknowledgement failed; aborting before mutation"
        MANAGER_EXIT_REASON="handoff-ack-failed"
        return 1
      fi
    fi
  fi
  merv_native_auth_snapshot

  # mervlan_manager always logs MAC shield activity regardless of the global default
  MAC_SHIELD_VERBOSE=1

  # Clean up stale self-restart markers (older than 60s past expiry)
  # These markers prevent heal_event.sh loops but should not persist forever
  _stale_marker="$LOCKDIR/self_restart.marker"
  if [ -f "$_stale_marker" ]; then
    _expiry=$(cat "$_stale_marker" 2>/dev/null || echo 0)
    case "$_expiry" in ''|*[!0-9]*) _expiry=0 ;; esac
    _now=$(date +%s)
    if [ $((_now - 60)) -gt "$_expiry" ]; then
      rm -f "$_stale_marker" 2>/dev/null || :
    fi
  fi

  # Pre-flight validation: verify required files and settings exist
  validate_configuration
  merv_action_progress_update validate 1 1 15 "Validating VLAN and SSID settings..."

  # Boot mode: wait for configured SSID interfaces to appear (reduces boot race conditions)
  # This only runs when invoked with "boot" argument from services-start
  boot_wait_for_configured_ssids 30

  # Boot mode: restore MERV_MAC shield from JFFS checkpoint before first apply
  if [ "$MERV_MANAGER_MODE" = "boot" ]; then
    merv_mac_boot_init
  fi

  # Log startup information
  info -c cli,vlan "Starting VLAN manager on $MODEL ($PRODUCTID)"
  info -c cli,vlan "WAN: $WAN_IF, Topology: $TOPOLOGY"
  info -c cli,vlan "Dry Run: $DRY_RUN, Persistent: $PERSISTENT"
  
  # Log NODE_ID mode
  if merv_is_valid_node_id "$NODE_ID" 2>/dev/null; then
    info -c cli,vlan "Node Mode: Using NODE${NODE_ID} Ethernet port overrides"
  else
    info -c cli,vlan "Node Mode: Using main Ethernet port configuration"
  fi

  # Validation phase 1: check all VLAN IDs for syntax errors before any changes
  info -c cli,vlan "Validating VLAN settings..."
  
  # Validate Ethernet port VLAN assignments (ETH1_VLAN, ETH2_VLAN, etc.)
  idx=1
  for eth in $ETH_PORTS; do
    vlan=$(read_json "ETH${idx}_VLAN" "$SETTINGS_FILE")
    [ -z "$vlan" ] && vlan="none"
    # Validate VLAN ID syntax (will error and stop if invalid)
    validate_vlan_id "$vlan"
    idx=$((idx+1))
  done

  # Validate SSID VLAN assignments (VLAN_01-VLAN_MAX_SSIDS, filtered by node assignment)
  i=1
  while [ $i -le "$MAX_SSIDS" ]; do
    ssid=$(get_ssid_slot_value "$i" "$SETTINGS_FILE")
    vlan=$(get_vlan_slot_value "$i" "$SETTINGS_FILE")
    # Only validate if SSID is configured (not empty or placeholder)
    [ -n "$ssid" ] && [ "$ssid" != "unused-placeholder" ] && validate_vlan_id "$vlan"
    i=$((i+1))
  done

  # Cleanup phase: remove old VLAN infrastructure from previous runs
  # Enable the iface→VID cache for the duration of the apply hot path. The
  # cache is shared by ebt_quarantine_ensure_expected_rules, merv_managed_wl_ifaces
  # (via lib_br0_guard.sh) and merv_qt_ensure_expected_rules. It is invalidated
  # below after restart_services returns because rc/wlconf can reshuffle
  # wl*.*_ifname NVRAM mappings, and disabled before the final security check
  # and snapshot so they always see fresh state.
  type merv_iface_vid_cache_enable >/dev/null 2>&1 && merv_iface_vid_cache_enable
  if [ "$DRY_RUN" != "yes" ]; then
    if ! merv_dhcp_hold_mark_mutating "$MANAGER_DHCP_TOKEN" bridge-cleanup; then
      error -c cli,vlan "Cannot publish manager mutation phase; aborting before bridge cleanup"
      return 1
    fi
  fi
  cleanup_existing_config
  merv_action_progress_update cleanup 1 1 25 "Cleaning previous VLAN configuration..."

  # Configuration phase 1: Attach Ethernet LAN ports to appropriate bridges
  if [ -n "$ETH_PORTS" ]; then
    idx=1
    for eth in $ETH_PORTS; do
      vlan=$(read_json "ETH${idx}_VLAN" "$SETTINGS_FILE")
      [ -z "$vlan" ] && vlan="none"
      # Attach Ethernet port to br0 (untagged) or brVID (tagged)
      attach_to_bridge "$eth" "$vlan" "LAN Port $idx"
      idx=$((idx+1))
    done
  fi
  merv_action_progress_update configure 1 2 40 "Configuring Ethernet bridges and ports..."

  # Configuration phase 2: Bind all configured SSIDs dynamically (1..MAX_SSIDS)
  # This includes restoring unconfigured SSIDs to br0
  WATCHDOG_QUEUE_LOG=0
  export WATCHDOG_QUEUE_LOG
  bind_configured_ssids

  # Configuration phase 3: Apply AP isolation policies across all SSIDs
  # Iterate through configured SSIDs and apply APISO settings (filtered by node assignment)
  i=1
  while [ $i -le "$MAX_SSIDS" ]; do
    ssid=$(get_ssid_slot_value "$i" "$SETTINGS_FILE")
    apiso=$(get_apiso_slot_value "$i" "$SETTINGS_FILE")
    # Apply AP isolation if SSID is configured and APISO value is set
    if [ -n "$ssid" ] && [ "$ssid" != "unused-placeholder" ] && [ -n "$apiso" ]; then
      _apiso_iflist=$(find_if_by_ssid_any "$ssid")
      if [ -n "$_apiso_iflist" ]; then
        printf '%s\n' "$_apiso_iflist" | while IFS= read -r _apiso_ifn; do
          [ -n "$_apiso_ifn" ] || continue
          set_ap_isolation "$_apiso_ifn" "$apiso"
        done
      fi
    fi
    i=$((i+1))
  done
  merv_action_progress_update configure 2 2 55 "Applying SSID and isolation settings..."

  # Service restart phase: only if not in dry-run mode
  [ "$DRY_RUN" = "yes" ] || {
    merv_action_progress_update restart 1 3 65 "Restarting wireless services..."
    # Restart WiFi services to pick up new VAP configuration
    restart_services
    merv_action_progress_update restart 2 3 72 "Waiting for wireless services to settle..."

    # rc/wlconf may have reshuffled wl*.*_ifname NVRAM mappings during the
    # restart. Invalidate the iface→VID cache so the next read rebuilds from
    # post-rc NVRAM. The cache stays enabled and is repopulated on first use
    # below — that one rebuild is then reused across all post-restart shield
    # re-arm calls (soft evict + ebt_quarantine_ensure + post_qt rebuild).
    type merv_iface_vid_cache_invalidate >/dev/null 2>&1 && merv_iface_vid_cache_invalidate

    # Immediate bridge-only sweep after restart_services returns:
    # rc/wlconf may already have recreated VAPs and attached them to br0.
    type merv_soft_evict_wl_from_br0 >/dev/null 2>&1 && \
      merv_soft_evict_wl_from_br0 "manager-post-restart"

    if is_ap_mode; then
      info -c cli,vlan "Waiting briefly for AP-mode switch rc to go quiet..."
      if ! wait_for_rc_quiet 2 10; then
        error -c cli,vlan "rc remained active after AP-mode restart wait; aborting bridge mutation"
        return 1
      fi
    else
      info -c cli,vlan "Waiting for rc/wlconf to go quiet..."
      if ! wait_for_rc_quiet 6 30; then
        error -c cli,vlan "rc/wlconf remained active after restart wait; aborting bridge mutation"
        return 1
      fi
    fi

    type merv_soft_evict_wl_from_br0 >/dev/null 2>&1 && \
      merv_soft_evict_wl_from_br0 "manager-post-quiet"

    # Explicit re-arm immediately when rc goes quiet — before the 2s settle sleep.
    # The wait loop above restores shields every 1s tick, so this is largely
    # belt-and-suspenders, but it guarantees a clean slate is committed the
    # moment the manager confirms rc is done with restart_wireless.
    if type ebtables >/dev/null 2>&1; then
      info -c cli,vlan "Re-arming L2 shields post-restart_wireless..."
      ebt_quarantine_ensure_expected_rules
      _post_qt_count=0
      if type merv_iface_vid_list >/dev/null 2>&1; then
        _post_qt_ifaces=$(merv_iface_vid_list | awk '{print $1}')
      else
        _post_qt_ifaces=$(merv_mac_build_expected_iface_vid 2>/dev/null | awk '{print $1}')
      fi
      for _post_qt_if in $_post_qt_ifaces; do
        [ -n "$_post_qt_if" ] || continue
        _post_qt_count=$((_post_qt_count + 1))
      done
      [ "$_post_qt_count" -gt 0 ] && \
        info -c cli,vlan "MERV_QT: re-armed for $_post_qt_count interface(s) post-restart"
      ebt_mac_shield_init_and_apply "$(merv_mac_best_db 2>/dev/null || true)"
    fi

    # Bridge-only sweep after shields are re-armed, before the settle sleep.
    type merv_soft_evict_wl_from_br0 >/dev/null 2>&1 && \
      merv_soft_evict_wl_from_br0 "manager-post-shield"

    # Guard-tick during the 2s settle so an rc ebtables flush here is restored
    # within 1s rather than surviving until the next explicit re-arm point.
    merv_guarded_sleep 2

    # Second pass for new VAPs that appear after wireless restart
  info -c cli,vlan "Second pass for new VAPs..."
  WATCHDOG_QUEUE_LOG=1
  export WATCHDOG_QUEUE_LOG
    bind_configured_ssids

    # Disable the iface→VID cache so post_rc_watchdog, the final security
    # check, and the backgrounded MERV_MAC snapshot all see fresh NVRAM.
    type merv_iface_vid_cache_disable >/dev/null 2>&1 && merv_iface_vid_cache_disable

    MANAGER_SETTLE_VERIFIED=0
    post_rc_watchdog && MANAGER_SETTLE_VERIFIED=1
    merv_action_progress_update restart 3 3 82 "Rebinding interfaces and rearming security rules..."

  }

  run_trunk_if_configured

  merv_native_auth_audit

  if [ "$DRY_RUN" != "yes" ]; then
    merv_action_progress_update verify 1 2 90 "Running final VLAN security verification..."
    if [ "${MANAGER_SETTLE_VERIFIED:-0}" -eq 1 ] && merv_manager_final_security_check; then
      merv_action_progress_update verify 2 2 95 "Final VLAN security verification passed..."
      _manager_verification="${MANAGER_RUN_ID}-final-$(date +%s 2>/dev/null || echo 0)"
      if ! merv_dhcp_hold_mark_verified "$MANAGER_DHCP_TOKEN" "$_manager_verification"; then
        error -c cli,vlan "SECURITY FAIL: could not publish verified manager phase"
        MANAGER_EXIT_REASON="verify-publish-failed"
        return 1
      fi
      if [ -n "$MANAGER_HANDOFF_ID" ] &&
         ! merv_dhcp_handoff_child_verified "$MANAGER_HANDOFF_ID" "$MANAGER_DHCP_TOKEN" "$_manager_verification"; then
        error -c cli,vlan "SECURITY FAIL: could not publish verified handoff completion"
        MANAGER_EXIT_REASON="handoff-completion-failed"
        return 1
      fi
      if [ -f "$MERV_DHCP_HOLD_STATE_ROOT/recovery.pending" ]; then
        if ! merv_dhcp_hold_clear_failsafes "$MANAGER_DHCP_TOKEN" "$_manager_verification"; then
          error -c cli,vlan "SECURITY FAIL: verified manager could not clear covered failsafes"
          MANAGER_EXIT_REASON="failsafe-clear-failed"
          return 1
        fi
      fi
      if ! merv_dhcp_hold_release "$MANAGER_DHCP_TOKEN"; then
        error -c cli,vlan "Manager lease release incomplete; reconciliation will retry"
        MANAGER_EXIT_REASON="verified-release-failed"
        return 1
      fi
      MANAGER_DHCP_TOKEN=""
    else
      error -c cli,vlan "SECURITY FAIL: final placement verification failed; converting manager lease to failsafe"
      MERV_DHCP_FAILSAFE_FAILED_INTERFACES="${WATCH_IFACES:-unknown}"
      MERV_DHCP_FAILSAFE_EXPECTED_BRIDGES="${WATCH_IFACES:-unknown}"
      MERV_DHCP_FAILSAFE_OBSERVED_BRIDGES="final-security-check-failed"
      MERV_DHCP_FAILSAFE_MISSING_RULES="$(merv_dhcp_hold_rules_observed 2>/dev/null || printf unavailable)"
      if rc_queue_has 'restart_wireless|start_lan|stop_lan|switch' ||
         rc_proc_busy 'restart_wireless|wlconf|start_lan|switch'; then
        MERV_DHCP_FAILSAFE_ASUS_WORK=active
      else
        MERV_DHCP_FAILSAFE_ASUS_WORK=quiet
      fi
      MERV_DHCP_FAILSAFE_SUGGESTED_ACTION=mervlan-manager-recovery
      export MERV_DHCP_FAILSAFE_FAILED_INTERFACES MERV_DHCP_FAILSAFE_EXPECTED_BRIDGES
      export MERV_DHCP_FAILSAFE_OBSERVED_BRIDGES MERV_DHCP_FAILSAFE_MISSING_RULES
      export MERV_DHCP_FAILSAFE_ASUS_WORK MERV_DHCP_FAILSAFE_SUGGESTED_ACTION
      if merv_dhcp_hold_abandon "$MANAGER_DHCP_TOKEN" final-verification-failed; then
        MANAGER_DHCP_TOKEN=""
      fi
      MANAGER_EXIT_REASON="final-verification-failed"
      return 1
    fi
  fi

  # Summary: display final configuration status
  show_configuration_summary

  info -c cli,vlan "VLAN manager run completed at $(date '+%H:%M:%S')"

  if [ "$DRY_RUN" = "yes" ]; then
    info -c cli,vlan "Dry-run mode; skipping VLAN client list refresh (collect_clients.sh)"
  elif [ "$MERV_IS_NODE" = "1" ]; then
    "$FUNCDIR/post_apply_worker.sh" request snapshot >/dev/null 2>&1 || \
      warn -c cli,vlan "Node post-apply snapshot request failed"
  elif [ "$SKIP_COLLECT" = "yes" ]; then
    info -c cli,vlan "Parallel mode; cluster observation will follow node verification"
  elif [ -x "$FUNCDIR/post_apply_worker.sh" ]; then
    merv_action_progress_update complete 1 1 98 "Refreshing client inventory..."
    info -c cli,vlan "Refreshing client inventory after apply..."
    if MERV_OBS_NO_AUTOSTART=1 "$FUNCDIR/post_apply_worker.sh" \
         request snapshot collect >/dev/null 2>&1 &&
       "$FUNCDIR/post_apply_worker.sh" run-wait "${MERV_OBS_AUTOSTART_WAIT_SEC:-120}"; then
      info -c cli,vlan "✓ VLAN client list refresh completed"
    else
      _manager_observation_rc=$?
      warn -c cli,vlan "✗ Post-apply observation failed (rc=$_manager_observation_rc); generation remains pending"
      MANAGER_EXIT_REASON="post-apply-observation-failed"
      return 1
    fi
  else
    warn -c cli,vlan "Post-apply observation unavailable; client inventory was not refreshed"
    MANAGER_EXIT_REASON="post-apply-observation-unavailable"
    return 1
  fi
}

# Entry point: call main with command-line arguments
main "$@"
