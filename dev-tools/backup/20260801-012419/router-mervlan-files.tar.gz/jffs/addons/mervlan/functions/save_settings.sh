#!/bin/sh
#
# ============================================================================ #
#                                                                              #
#   /$$      /$$                     /$$    /$$ /$$        /$$$$$$  /$$   /$$  #
#  | $$$    /$$$                    | $$   | $$| $$       /$$__  $$| $$$ | $$  #
#  | $$$$  /$$$$  /$$$$$$   /$$$$$$ | $$   | $$| $$      | $$  \ $$| $$$$| $$  #
#  | $$ $$/$$ $$ /$$__  $$ /$$__  $$|  $$ / $$/| $$      | $$$$$$$$| $$ $$ $$  #
#  | $$  $$$| $$| $$$$$$$$| $$  \__/ \  $$ $$/ | $$      | $$__  $$| $$  $$$$  #
#  | $$\  $ | $$| $$_____/| $$        \  $$$/  | $$      | $$  | $$| $$\  $$$  #
#  | $$ \/  | $$|  $$$$$$$| $$         \  $/   | $$$$$$$$| $$  | $$| $$ \  $$  #
#  |__/     |__/ \_______/|__/          \_/    |________/|__/  |__/|__/  \__/  #
#                                                                              #
# ============================================================================ #
#               - File: save_settings.sh || version="0.53"                     #
# ============================================================================ #
# - Purpose:    Save current vlanmgr_* settings from custom_settings.txt into  #
#               settings.json (persistent storage) and public settings.json.   #
#               Also ensures custom_settings.txt has correct header line.      #
# ============================================================================ #
#                                                                              #
# ================================================== MerVLAN environment setup #
: "${MERV_BASE:=/jffs/addons/mervlan}"
: "${MERV_STATE_ROOT:=/jffs/addons/mervlan_state}"
if { [ -n "${VAR_SETTINGS_LOADED:-}" ] && [ -z "${LOG_SETTINGS_LOADED:-}" ]; } || \
   { [ -z "${VAR_SETTINGS_LOADED:-}" ] && [ -n "${LOG_SETTINGS_LOADED:-}" ]; }; then
  unset VAR_SETTINGS_LOADED LOG_SETTINGS_LOADED LIB_JSON_LOADED
fi
[ -n "${VAR_SETTINGS_LOADED:-}" ] || . "$MERV_BASE/settings/var_settings.sh"
[ -n "${LOG_SETTINGS_LOADED:-}" ] || . "$MERV_BASE/settings/log_settings.sh"
[ -n "${LIB_JSON_LOADED:-}" ] || . "$MERV_BASE/settings/lib_json.sh"
if [ "${MERV_ACTION_LOCK_PARENT_HELD:-0}" != "1" ] && [ -f "$MERV_BASE/settings/lib_action_lock.sh" ]; then
    . "$MERV_BASE/settings/lib_action_lock.sh" 2>/dev/null || exit 1
    merv_action_lock_acquire "${MERV_ACTION_LOCK_PATH:-${LOCKDIR:-/tmp/mervlan_tmp/locks}/mervlan_action.lock}" || exit 75
    _save_action_lock_nonce="$MERV_ACTION_LOCK_NONCE"; _save_action_lock_start="$MERV_ACTION_LOCK_START"
    _save_release_lock() {
        _save_exit_rc=$?
        if ! merv_action_lock_release "${MERV_ACTION_LOCK_PATH:-${LOCKDIR:-/tmp/mervlan_tmp/locks}/mervlan_action.lock}" "$_save_action_lock_nonce" "$_save_action_lock_start" >/dev/null 2>&1; then
            printf '%s\n' "[ERROR] save-settings action-lock cleanup failed; lock retained for recovery" >&2
            [ "$_save_exit_rc" -eq 0 ] && _save_exit_rc=75
        fi
        return "$_save_exit_rc"
    }
    trap '_save_release_lock' EXIT INT TERM
fi
# =========================================== End of MerVLAN environment setup #
# ============================================================================ #
#                                    HELPERS                                   #
# Utility functions for managing custom_settings.txt and ensuring correct      #
# header lines before JSON conversion. These helpers ensure the file is in     #
# a consistent state before we begin extracting and converting settings.       #
# ============================================================================ #

# ============================================================================ #
# ensure_custom_settings_header                                                #
# Verify and update the first line of custom_settings_file with the version    #
# from changelog. Creates file if missing, replaces old header if present.     #
# ============================================================================ #
ensure_custom_settings_header() {
    # custom_settings.txt is an external Merlin-owned transport file.  It is
    # never rewritten by MerVLAN; the locked ledger capture below is the only
    # durable fallback copy.
    [ -f "${CUSTOM_SETTINGS_FILE}" ] || return 1
    return 0
}

# ============================================================================ #
# sort_vlanmgr_block_in_custom_settings                                        #
# Sort only lines starting with "vlanmgr_" alphabetically, directly in        #
# custom_settings.txt.                                                        #
#                                                                             #
# Guarantees:                                                                 #
# - First line (header) preserved as-is (already ensured by                   #
#   ensure_custom_settings_header).                                           #
# - Only lines that START with "vlanmgr_" are reordered.                      #
# - All other lines are kept byte-for-byte and in their original order.       #
# - No third-party or user lines are modified or deleted.                     #
# ============================================================================ #
sort_vlanmgr_block_in_custom_settings() {
    # If file doesn't exist, nothing to do
    [ -f "${CUSTOM_SETTINGS_FILE}" ] || return 0
    return 0

    : <<'MERV_LEGACY_NOOP'
        tail -n +2 "${CUSTOM_SETTINGS_FILE}" 2>/dev/null | while IFS= read -r line; do
            case "${line}" in
                vlanmgr_*) : ;;          # our keys → already re-emitted sorted above
                *) printf '%s\n' "$line" ;;
            esac
        done
    :

    :
MERV_LEGACY_NOOP
}

# ============================================================================ #
#                               INITIALIZATION                                 #
# Create required directories, prepare temporary files, and validate the       #
# custom_settings_file before processing. This ensures all paths are ready     #
# and the file structure is correct for the conversion pipeline.               #
# ============================================================================ #

info -c vlan "save_settings.sh: start"

# Detect ETH port capacity from Hardware section if not already set
if [ -z "${MAX_ETH_PORTS:-}" ]; then
    if [ -f "$HW_SETTINGS_FILE" ]; then
        MAX_ETH_PORTS="$(json_get_hw_int "MAX_ETH_PORTS" "" "$HW_SETTINGS_FILE" 2>/dev/null)"
    fi
fi

# Detect TRUNK port capacity (mirrors ETH/LAN unless overridden)
if [ -z "${MAX_TRUNK_PORTS:-}" ]; then
    if [ -n "${MAX_ETH_PORTS:-}" ]; then
        MAX_TRUNK_PORTS="$MAX_ETH_PORTS"
    else
        MAX_TRUNK_PORTS=8
    fi
fi

# Clamp to supported range (1-8)
case "$MAX_TRUNK_PORTS" in
    ''|*[!0-9]*) MAX_TRUNK_PORTS=8 ;;
esac
[ "$MAX_TRUNK_PORTS" -lt 1 ] && MAX_TRUNK_PORTS=1
[ "$MAX_TRUNK_PORTS" -gt 8 ] && MAX_TRUNK_PORTS=8

info -c vlan "save_settings.sh: MAX_ETH_PORTS=${MAX_ETH_PORTS:-unset}, MAX_TRUNK_PORTS=$MAX_TRUNK_PORTS"

# Create settings directory; abort if it fails
mkdir -p "${SETTINGSDIR}" || {
    error -c vlan "save_settings.sh: ERROR can't mkdir ${SETTINGSDIR}"
    exit 1
}

# Create results directory for temporary files; abort if it fails
mkdir -p "${RESULTDIR}" || {
    error -c vlan "save_settings.sh: ERROR can't mkdir ${RESULTDIR}"
    exit 1
}

# Initialize temporary file paths with PID suffix to avoid collisions on concurrent runs
TMP_KV="${RESULTDIR}/vlanmgr_kv.$$"
TMP_SORTED="${RESULTDIR}/vlanmgr_sorted.$$"
TMP_JSON="${RESULTDIR}/vlanmgr_json.$$"

# Truncate temporary files to empty state
> "${TMP_KV}"
> "${TMP_SORTED}"
> "${TMP_JSON}"

# Locked legacy fallback ledger.  Capture the external transport exactly once
# before parsing it; no MerVLAN code rewrites or sorts the Merlin-owned file.
if [ ! -f "${CUSTOM_SETTINGS_FILE}" ]; then
    error -c vlan "save_settings.sh: external custom settings transport is unavailable"
    exit 1
fi
mkdir -p "${MERV_STATE_ROOT}/ledgers" 2>/dev/null || exit 1
_save_ledger_tmp="${MERV_STATE_ROOT}/ledgers/custom_settings.$$"
( umask 077; cp "${CUSTOM_SETTINGS_FILE}" "$_save_ledger_tmp" ) 2>/dev/null || { rm -f "$_save_ledger_tmp" 2>/dev/null; exit 1; }
chmod 600 "$_save_ledger_tmp" 2>/dev/null || { rm -f "$_save_ledger_tmp" 2>/dev/null; exit 1; }
mv -f "$_save_ledger_tmp" "${MERV_STATE_ROOT}/ledgers/custom_settings.latest" 2>/dev/null || { rm -f "$_save_ledger_tmp" 2>/dev/null; exit 1; }

# Ensure custom_settings_file has correct version header
ensure_custom_settings_header

# Sort only our vlanmgr_* block inside custom_settings.txt
sort_vlanmgr_block_in_custom_settings

# Abort if custom_settings_file still doesn't exist after header ensure
if [ ! -f "${CUSTOM_SETTINGS_FILE}" ]; then
    error -c vlan "save_settings.sh: ${CUSTOM_SETTINGS_FILE} not found even after ensure_custom_settings_header, abort"
    exit 1
fi

# ============================================================================ #
# STEP 1: Extract vlanmgr_* keys and values                                    #
# Parse custom_settings_file and extract all lines matching vlanmgr_* prefix.  #
# Store as key-value pairs (tab-separated) with prefix removed for JSON keys.  #
# ============================================================================ #

while IFS= read -r LINE; do
    case "${LINE}" in
        vlanmgr_*)
            # Extract key part (everything before first space)
            KEY="${LINE%% *}"
            # Extract value part (everything after first space)
            VAL="${LINE#* }"
            # If no value found, key and value are same; set value to empty string
            if [ "${VAL}" = "${KEY}" ]; then
                VAL=""
            fi

            # Remove "vlanmgr_" prefix from key for JSON output
            SHORT_KEY="${KEY#vlanmgr_}"

            # Write tab-separated key-value pair to temporary file
            printf '%s\t%s\n' "${SHORT_KEY}" "${VAL}" >> "${TMP_KV}"
        ;;
    esac
done < "${CUSTOM_SETTINGS_FILE}"

# ============================================================================ #
# STEP 2: Sort keys alphabetically                                             #
# Sort the extracted key-value pairs by key name to create a predictable       #
# ordering in the JSON output. This makes diffs and manual inspection easier.  #
# ============================================================================ #

# Sort by first column (key name) to ensure consistent ordering across runs
sort -k1,1 "${TMP_KV}" > "${TMP_SORTED}"

# ============================================================================ #
# STEP 1.5: Extract and remove SAVE_SCOPE                                      #
# The UI sends vlanmgr_SAVE_SCOPE to indicate which subset of keys are present  #
# in this payload (normal/override/clientmeta/full). It must not be written    #
# into settings.json. Remove it here before any further processing.            #
# ============================================================================ #

SAVE_SCOPE="$(awk -F'\t' '$1=="SAVE_SCOPE"{print $2; exit}' "${TMP_KV}")"
case "$SAVE_SCOPE" in
    normal|override|clientmeta|full) :;;
    *) SAVE_SCOPE="full" ;; # backward-compatible: old UI sends no SAVE_SCOPE
esac
info -c vlan "save_settings.sh: SAVE_SCOPE=$SAVE_SCOPE"

# Strip SAVE_SCOPE key from TMP_KV — must never reach settings.json
_tmp_kv_scoped="${TMP_KV}.scoped.$$"
grep -v '^SAVE_SCOPE	' "${TMP_KV}" > "${_tmp_kv_scoped}" && mv "${_tmp_kv_scoped}" "${TMP_KV}" || rm -f "${_tmp_kv_scoped}"

# Re-sort after stripping SAVE_SCOPE
sort -k1,1 "${TMP_KV}" > "${TMP_SORTED}"

# Request-correlation fields are transport metadata for one action. They must
# never become persistent MerVLAN settings when a progress-enabled save later
# uses the shared MVM_exec path.
_tmp_kv_transport="${TMP_KV}.transport.$$"
grep -v '^\(progress_token\|action_request_token\|sshtrust_[A-Za-z0-9_]*\)[[:space:]]' "${TMP_KV}" > "${_tmp_kv_transport}" || :
if [ -f "${_tmp_kv_transport}" ]; then
    mv "${_tmp_kv_transport}" "${TMP_KV}"
else
    rm -f "${_tmp_kv_transport}"
fi
sort -k1,1 "${TMP_KV}" > "${TMP_SORTED}"

# ============================================================================ #
# STEP 1.6: Scope filter                                                       #
# Keep only the keys relevant to this save scope. This prevents stale          #
# vlanmgr_* lines already present in custom_settings.txt from bleeding into   #
# the wrong section when a scoped (override/clientmeta) save runs.             #
# ============================================================================ #
_tmp_kv_filtered="${TMP_KV}.filtered.$$"
case "$SAVE_SCOPE" in
    normal)
        # Keep VLAN/node/SSID/trunk/general keys; drop OVERRIDE_* and ClientMeta.
        awk -F'\t' '
            $1 !~ /^OVERRIDE_/ &&
            $1 != "MAC_SHIELD_OVERRIDES" &&
            $1 != "CLIENT_NAME_OVERRIDES" { print }
        ' "${TMP_KV}" > "${_tmp_kv_filtered}" && mv "${_tmp_kv_filtered}" "${TMP_KV}" || rm -f "${_tmp_kv_filtered}"
        ;;
    override)
        # Keep only OVERRIDE_* keys.
        awk -F'\t' '$1 ~ /^OVERRIDE_/ { print }' "${TMP_KV}" > "${_tmp_kv_filtered}" && \
            mv "${_tmp_kv_filtered}" "${TMP_KV}" || rm -f "${_tmp_kv_filtered}"
        ;;
    clientmeta)
        # Keep only ClientMeta keys.
        awk -F'\t' '$1 == "MAC_SHIELD_OVERRIDES" || $1 == "CLIENT_NAME_OVERRIDES" { print }' \
            "${TMP_KV}" > "${_tmp_kv_filtered}" && \
            mv "${_tmp_kv_filtered}" "${TMP_KV}" || rm -f "${_tmp_kv_filtered}"
        ;;
    full)
        : # keep everything already in TMP_KV
        ;;
esac

# Re-sort after scope filter
sort -k1,1 "${TMP_KV}" > "${TMP_SORTED}"

# ============================================================================ #
# STEP 2.5: Enforce ETHn_VLAN / trunkn safety                                  #
# Prevents a port from being both an access VLAN and a trunk simultaneously.    #
# ============================================================================ #
enforce_trunk_eth_exclusivity() {
    local TMP_FINAL idx val tmp_idx CONFIG_MAX_TRUNK_PORTS
    local TRUNK1 TRUNK2 TRUNK3 TRUNK4 TRUNK5 TRUNK6 TRUNK7 TRUNK8
    local ETH1 ETH2 ETH3 ETH4 ETH5 ETH6 ETH7 ETH8
    local TRUNK1_FINAL TRUNK2_FINAL TRUNK3_FINAL TRUNK4_FINAL TRUNK5_FINAL TRUNK6_FINAL TRUNK7_FINAL TRUNK8_FINAL
    local ETH1_FINAL ETH2_FINAL ETH3_FINAL ETH4_FINAL ETH5_FINAL ETH6_FINAL ETH7_FINAL ETH8_FINAL
    local FORCE_ETH1 FORCE_ETH2 FORCE_ETH3 FORCE_ETH4 FORCE_ETH5 FORCE_ETH6 FORCE_ETH7 FORCE_ETH8
    local FORCE_TRUNK1 FORCE_TRUNK2 FORCE_TRUNK3 FORCE_TRUNK4 FORCE_TRUNK5 FORCE_TRUNK6 FORCE_TRUNK7 FORCE_TRUNK8

    TMP_FINAL="${RESULTDIR}/vlanmgr_final.$$"
    CONFIG_MAX_TRUNK_PORTS=0

    TRUNK1=0; TRUNK2=0; TRUNK3=0; TRUNK4=0
    TRUNK5=0; TRUNK6=0; TRUNK7=0; TRUNK8=0
    ETH1=""; ETH2=""; ETH3=""; ETH4=""
    ETH5=""; ETH6=""; ETH7=""; ETH8=""

    _save_tab=$(printf '\t')
    while IFS="$_save_tab" read -r key val; do
        case "$key" in
            TRUNK1|trunk1) TRUNK1="$val" ;;
            TRUNK2|trunk2) TRUNK2="$val" ;;
            TRUNK3|trunk3) TRUNK3="$val" ;;
            TRUNK4|trunk4) TRUNK4="$val" ;;
            TRUNK5|trunk5) TRUNK5="$val" ;;
            TRUNK6|trunk6) TRUNK6="$val" ;;
            TRUNK7|trunk7) TRUNK7="$val" ;;
            TRUNK8|trunk8) TRUNK8="$val" ;;
            TAGGED_TRUNK[1-8])
                tmp_idx="${key#TAGGED_TRUNK}"
                case "$tmp_idx" in
                    ''|*[!0-9]*) : ;;
                    *)
                        if [ "$tmp_idx" -gt "$CONFIG_MAX_TRUNK_PORTS" ]; then
                            CONFIG_MAX_TRUNK_PORTS="$tmp_idx"
                        fi
                        ;;
                esac
                ;;
            UNTAGGED_TRUNK[1-8])
                tmp_idx="${key#UNTAGGED_TRUNK}"
                case "$tmp_idx" in
                    ''|*[!0-9]*) : ;;
                    *)
                        if [ "$tmp_idx" -gt "$CONFIG_MAX_TRUNK_PORTS" ]; then
                            CONFIG_MAX_TRUNK_PORTS="$tmp_idx"
                        fi
                        ;;
                esac
                ;;
            ETH1_VLAN) ETH1="$val" ;;
            ETH2_VLAN) ETH2="$val" ;;
            ETH3_VLAN) ETH3="$val" ;;
            ETH4_VLAN) ETH4="$val" ;;
            ETH5_VLAN) ETH5="$val" ;;
            ETH6_VLAN) ETH6="$val" ;;
            ETH7_VLAN) ETH7="$val" ;;
            ETH8_VLAN) ETH8="$val" ;;
        esac
    done < "${TMP_SORTED}"

    if [ "$CONFIG_MAX_TRUNK_PORTS" -gt 0 ] && [ "$CONFIG_MAX_TRUNK_PORTS" -lt "$MAX_TRUNK_PORTS" ]; then
        info -c vlan "save_settings.sh: configured trunk keys cap MAX_TRUNK_PORTS to $CONFIG_MAX_TRUNK_PORTS"
        MAX_TRUNK_PORTS="$CONFIG_MAX_TRUNK_PORTS"
    fi

    TRUNK1_FINAL="$TRUNK1"; TRUNK2_FINAL="$TRUNK2"; TRUNK3_FINAL="$TRUNK3"; TRUNK4_FINAL="$TRUNK4"
    TRUNK5_FINAL="$TRUNK5"; TRUNK6_FINAL="$TRUNK6"; TRUNK7_FINAL="$TRUNK7"; TRUNK8_FINAL="$TRUNK8"
    ETH1_FINAL="$ETH1"; ETH2_FINAL="$ETH2"; ETH3_FINAL="$ETH3"; ETH4_FINAL="$ETH4"
    ETH5_FINAL="$ETH5"; ETH6_FINAL="$ETH6"; ETH7_FINAL="$ETH7"; ETH8_FINAL="$ETH8"

    FORCE_ETH1=0; FORCE_ETH2=0; FORCE_ETH3=0; FORCE_ETH4=0
    FORCE_ETH5=0; FORCE_ETH6=0; FORCE_ETH7=0; FORCE_ETH8=0
    FORCE_TRUNK1=0; FORCE_TRUNK2=0; FORCE_TRUNK3=0; FORCE_TRUNK4=0
    FORCE_TRUNK5=0; FORCE_TRUNK6=0; FORCE_TRUNK7=0; FORCE_TRUNK8=0

    if [ "$TRUNK1" = "1" ]; then
        if [ -n "$ETH1" ] && [ "$ETH1" != "none" ]; then
            ETH1_FINAL="none"
            FORCE_ETH1=1
        fi
    else
        if [ -n "$ETH1" ] && [ "$ETH1" != "none" ]; then
            if [ "$TRUNK1" != "0" ]; then
                FORCE_TRUNK1=1
            fi
            TRUNK1_FINAL="0"
        fi
    fi

    if [ "$TRUNK2" = "1" ]; then
        if [ -n "$ETH2" ] && [ "$ETH2" != "none" ]; then
            ETH2_FINAL="none"
            FORCE_ETH2=1
        fi
    else
        if [ -n "$ETH2" ] && [ "$ETH2" != "none" ]; then
            if [ "$TRUNK2" != "0" ]; then
                FORCE_TRUNK2=1
            fi
            TRUNK2_FINAL="0"
        fi
    fi

    if [ "$TRUNK3" = "1" ]; then
        if [ -n "$ETH3" ] && [ "$ETH3" != "none" ]; then
            ETH3_FINAL="none"
            FORCE_ETH3=1
        fi
    else
        if [ -n "$ETH3" ] && [ "$ETH3" != "none" ]; then
            if [ "$TRUNK3" != "0" ]; then
                FORCE_TRUNK3=1
            fi
            TRUNK3_FINAL="0"
        fi
    fi

    if [ "$TRUNK4" = "1" ]; then
        if [ -n "$ETH4" ] && [ "$ETH4" != "none" ]; then
            ETH4_FINAL="none"
            FORCE_ETH4=1
        fi
    else
        if [ -n "$ETH4" ] && [ "$ETH4" != "none" ]; then
            if [ "$TRUNK4" != "0" ]; then
                FORCE_TRUNK4=1
            fi
            TRUNK4_FINAL="0"
        fi
    fi

    if [ "$TRUNK5" = "1" ]; then
        if [ -n "$ETH5" ] && [ "$ETH5" != "none" ]; then
            ETH5_FINAL="none"
            FORCE_ETH5=1
        fi
    else
        if [ -n "$ETH5" ] && [ "$ETH5" != "none" ]; then
            if [ "$TRUNK5" != "0" ]; then
                FORCE_TRUNK5=1
            fi
            TRUNK5_FINAL="0"
        fi
    fi

    if [ "$TRUNK6" = "1" ]; then
        if [ -n "$ETH6" ] && [ "$ETH6" != "none" ]; then
            ETH6_FINAL="none"
            FORCE_ETH6=1
        fi
    else
        if [ -n "$ETH6" ] && [ "$ETH6" != "none" ]; then
            if [ "$TRUNK6" != "0" ]; then
                FORCE_TRUNK6=1
            fi
            TRUNK6_FINAL="0"
        fi
    fi

    if [ "$TRUNK7" = "1" ]; then
        if [ -n "$ETH7" ] && [ "$ETH7" != "none" ]; then
            ETH7_FINAL="none"
            FORCE_ETH7=1
        fi
    else
        if [ -n "$ETH7" ] && [ "$ETH7" != "none" ]; then
            if [ "$TRUNK7" != "0" ]; then
                FORCE_TRUNK7=1
            fi
            TRUNK7_FINAL="0"
        fi
    fi

    if [ "$TRUNK8" = "1" ]; then
        if [ -n "$ETH8" ] && [ "$ETH8" != "none" ]; then
            ETH8_FINAL="none"
            FORCE_ETH8=1
        fi
    else
        if [ -n "$ETH8" ] && [ "$ETH8" != "none" ]; then
            if [ "$TRUNK8" != "0" ]; then
                FORCE_TRUNK8=1
            fi
            TRUNK8_FINAL="0"
        fi
    fi

    if [ "$FORCE_ETH1" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk1=1, forcing ETH1_VLAN=none"
    fi
    if [ "$FORCE_ETH2" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk2=1, forcing ETH2_VLAN=none"
    fi
    if [ "$FORCE_ETH3" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk3=1, forcing ETH3_VLAN=none"
    fi
    if [ "$FORCE_ETH4" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk4=1, forcing ETH4_VLAN=none"
    fi
    if [ "$FORCE_ETH5" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk5=1, forcing ETH5_VLAN=none"
    fi
    if [ "$FORCE_ETH6" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk6=1, forcing ETH6_VLAN=none"
    fi
    if [ "$FORCE_ETH7" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk7=1, forcing ETH7_VLAN=none"
    fi
    if [ "$FORCE_ETH8" -eq 1 ]; then
        info -c vlan "save_settings.sh: trunk8=1, forcing ETH8_VLAN=none"
    fi

    if [ "$FORCE_TRUNK1" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH1_VLAN!=none, forcing trunk1=0"
    fi
    if [ "$FORCE_TRUNK2" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH2_VLAN!=none, forcing trunk2=0"
    fi
    if [ "$FORCE_TRUNK3" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH3_VLAN!=none, forcing trunk3=0"
    fi
    if [ "$FORCE_TRUNK4" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH4_VLAN!=none, forcing trunk4=0"
    fi
    if [ "$FORCE_TRUNK5" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH5_VLAN!=none, forcing trunk5=0"
    fi
    if [ "$FORCE_TRUNK6" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH6_VLAN!=none, forcing trunk6=0"
    fi
    if [ "$FORCE_TRUNK7" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH7_VLAN!=none, forcing trunk7=0"
    fi
    if [ "$FORCE_TRUNK8" -eq 1 ]; then
        info -c vlan "save_settings.sh: ETH8_VLAN!=none, forcing trunk8=0"
    fi

    > "$TMP_FINAL"

    _save_tab=$(printf '\t')
    while IFS="$_save_tab" read -r key val; do
        case "$key" in
            ETH1_VLAN) val="$ETH1_FINAL" ;;
            ETH2_VLAN) val="$ETH2_FINAL" ;;
            ETH3_VLAN) val="$ETH3_FINAL" ;;
            ETH4_VLAN) val="$ETH4_FINAL" ;;
            ETH5_VLAN) val="$ETH5_FINAL" ;;
            ETH6_VLAN) val="$ETH6_FINAL" ;;
            ETH7_VLAN) val="$ETH7_FINAL" ;;
            ETH8_VLAN) val="$ETH8_FINAL" ;;
            TRUNK1|trunk1) continue ;;
            TRUNK2|trunk2) continue ;;
            TRUNK3|trunk3) continue ;;
            TRUNK4|trunk4) continue ;;
            TRUNK5|trunk5) continue ;;
            TRUNK6|trunk6) continue ;;
            TRUNK7|trunk7) continue ;;
            TRUNK8|trunk8) continue ;;
        esac
        printf '%s\t%s\n' "$key" "$val" >> "$TMP_FINAL"
    done < "${TMP_SORTED}"

    idx=1
    while [ "$idx" -le "$MAX_TRUNK_PORTS" ]; do
        case "$idx" in
            1) val="$TRUNK1_FINAL" ;;
            2) val="$TRUNK2_FINAL" ;;
            3) val="$TRUNK3_FINAL" ;;
            4) val="$TRUNK4_FINAL" ;;
            5) val="$TRUNK5_FINAL" ;;
            6) val="$TRUNK6_FINAL" ;;
            7) val="$TRUNK7_FINAL" ;;
            8) val="$TRUNK8_FINAL" ;;
            *) val="0" ;;
        esac
        printf 'TRUNK%s\t%s\n' "$idx" "$val" >> "$TMP_FINAL"
        idx=$((idx + 1))
    done

    sort -k1,1 "$TMP_FINAL" > "${TMP_SORTED}"
    rm -f "$TMP_FINAL"
}

# Only meaningful for normal/full saves; override and clientmeta payloads
# contain no ETH*/TRUNK* keys so the enforcer would be a no-op and could
# synthesise unwanted defaults on a metadata-only save.
case "$SAVE_SCOPE" in
    normal|full) enforce_trunk_eth_exclusivity ;;
    *) : ;; # skip for override / clientmeta
esac

# ============================================================================ #
# STEP 2.8: Separate Hardware_Override keys from normal flat keys              #
# Override keys use the flat convention OVERRIDE_<TARGET>_<FIELD> and must be  #
# written into the nested Hardware_Override section via json_set_section2_value#
# instead of flat json_set_flag. Split them into a separate file here.         #
#                                                                             #
# ClientMeta keys (MAC_SHIELD_OVERRIDES, CLIENT_NAME_OVERRIDES) are likewise  #
# routed into the nested "ClientMeta" section via json_set_section_value. This #
# avoids json_set_flag's flat-append path landing the key inside an unrelated #
# nested object on installs where the section is missing.                      #
# ============================================================================ #

TMP_OVERRIDE="${RESULTDIR}/vlanmgr_override.$$"
TMP_CLIENTMETA="${RESULTDIR}/vlanmgr_clientmeta.$$"
TMP_NORMAL="${RESULTDIR}/vlanmgr_normal.$$"
> "${TMP_OVERRIDE}"
> "${TMP_CLIENTMETA}"
> "${TMP_NORMAL}"

while IFS="$(printf '\t')" read -r key value; do
    case "$key" in
        OVERRIDE_*) printf '%s\t%s\n' "$key" "$value" >> "${TMP_OVERRIDE}" ;;
        MAC_SHIELD_OVERRIDES|CLIENT_NAME_OVERRIDES)
                    printf '%s\t%s\n' "$key" "$value" >> "${TMP_CLIENTMETA}" ;;
        *)          printf '%s\t%s\n' "$key" "$value" >> "${TMP_NORMAL}" ;;
    esac
done < "${TMP_SORTED}"

# Replace TMP_SORTED with normal-only keys for json_apply_kv_file
cp "${TMP_NORMAL}" "${TMP_SORTED}"

# ============================================================================ #
# STEP 3: Merge into persistent settings.json                                   #
# Update the stored configuration in-place without overwriting unrelated keys. #
# ============================================================================ #

if ! json_apply_kv_file "${TMP_SORTED}" "${SETTINGS_FILE}"; then
    error -c vlan "save_settings.sh: failed to update ${SETTINGS_FILE}"
    rm -f "${TMP_KV}" "${TMP_SORTED}" "${TMP_JSON}" "${TMP_OVERRIDE}" "${TMP_CLIENTMETA}" "${TMP_NORMAL}"
    exit 1
fi

# ============================================================================ #
# STEP 3.5: Apply Hardware_Override keys into nested section                   #
# Map flat keys like OVERRIDE_MAIN_MAP_OVERRIDE → Hardware_Override.MAIN.MAP_OVERRIDE #
# ============================================================================ #

if [ -s "${TMP_OVERRIDE}" ]; then
    _ovr_fail=0
    while IFS="$(printf '\t')" read -r okey oval; do
        # Parse: OVERRIDE_<TARGET>_<FIELD>
        # TARGET is MAIN or NODE<n> (1..MERV_MAX_NODES); FIELD is MAP_OVERRIDE, WAN, MAX_ETH_PORTS, LAN1..LAN8
        _ovr_rest="${okey#OVERRIDE_}"
        case "$_ovr_rest" in
            MAIN_*)
                _ovr_target="MAIN"; _ovr_field="${_ovr_rest#MAIN_}"
                ;;
            NODE[0-9]*_*)
                # Extract the numeric node id and the remaining field name.
                _ovr_num="${_ovr_rest#NODE}"
                _ovr_num="${_ovr_num%%_*}"
                _ovr_field="${_ovr_rest#NODE${_ovr_num}_}"
                case "$_ovr_num" in
                    ''|*[!0-9]*)
                        warn -c vlan "save_settings.sh: unrecognised override key: $okey"; continue ;;
                esac
                if [ "$_ovr_num" -lt 1 ] || [ "$_ovr_num" -gt "${MERV_MAX_NODES:-10}" ]; then
                    warn -c vlan "save_settings.sh: override node out of range: $okey"; continue
                fi
                _ovr_target="NODE${_ovr_num}"
                ;;
            *) warn -c vlan "save_settings.sh: unrecognised override key: $okey"; continue ;;
        esac
        # Re-prefix FIELD to match JSON key names (OVERRIDE_WAN, OVERRIDE_LAN1, etc.)
        # MAP_OVERRIDE stays as-is; WAN→OVERRIDE_WAN, MAX_ETH_PORTS→OVERRIDE_MAX_ETH_PORTS, LAN*→OVERRIDE_LAN*
        case "$_ovr_field" in
            MAP_OVERRIDE) _ovr_json_key="MAP_OVERRIDE" ;;
            *)            _ovr_json_key="OVERRIDE_${_ovr_field}" ;;
        esac
        if ! json_set_section2_value "Hardware_Override" "$_ovr_target" "$_ovr_json_key" "$oval" "${SETTINGS_FILE}"; then
            warn -c vlan "save_settings.sh: failed to set Hardware_Override.$_ovr_target.$_ovr_json_key"
            _ovr_fail=1
        fi
    done < "${TMP_OVERRIDE}"
    if [ "$_ovr_fail" = "0" ]; then
        info -c vlan "save_settings.sh: Hardware_Override keys applied"
    fi
fi

# ============================================================================ #
# STEP 3.6: Apply ClientMeta keys into nested section                          #
# MAC_SHIELD_OVERRIDES / CLIENT_NAME_OVERRIDES are upserted into the           #
# "ClientMeta" section. json_set_section_value safely inserts the key inside   #
# that object even if the section exists without the key, and creates nothing  #
# unsafe if the section is missing (it simply no-ops the insert). The default  #
# settings.json ships the section so normal installs/updates always have it.   #
# ============================================================================ #

if [ -s "${TMP_CLIENTMETA}" ]; then
    # Defensive: the default/updated settings.json always ships a "ClientMeta"
    # section, but json_set_section_value silently no-ops (and still returns 0)
    # when the section is absent. So if it is somehow missing, seed an empty
    # section first — and log it — so the keys below actually persist instead of
    # vanishing without a trace.
    if ! grep -q '"ClientMeta"[[:space:]]*:' "${SETTINGS_FILE}" 2>/dev/null; then
        warn -c vlan "save_settings.sh: ClientMeta section missing — seeding it before write"
        _cm_seed_tmp="${SETTINGS_FILE}.cmseed.$$"
        if awk '
                BEGIN { seeded=0 }
                {
                    print
                    if (!seeded && $0 ~ /^[[:space:]]*\{[[:space:]]*$/) {
                        print "  \"ClientMeta\": {"
                        print "    \"_description\": \"MAC shield override and client display name configuration\","
                        print "    \"MAC_SHIELD_OVERRIDES\": \"\","
                        print "    \"CLIENT_NAME_OVERRIDES\": \"\""
                        print "  },"
                        seeded=1
                    }
                }
            ' "${SETTINGS_FILE}" > "${_cm_seed_tmp}" 2>/dev/null && [ -s "${_cm_seed_tmp}" ]; then
            mv "${_cm_seed_tmp}" "${SETTINGS_FILE}" 2>/dev/null || rm -f "${_cm_seed_tmp}" 2>/dev/null
        else
            rm -f "${_cm_seed_tmp}" 2>/dev/null
            warn -c vlan "save_settings.sh: failed to seed ClientMeta section"
        fi
    fi
    _cm_fail=0
    while IFS="$(printf '\t')" read -r cmkey cmval; do
        [ -n "$cmkey" ] || continue
        if ! json_set_section_value "ClientMeta" "$cmkey" "$cmval" "${SETTINGS_FILE}"; then
            warn -c vlan "save_settings.sh: failed to set ClientMeta.$cmkey"
            _cm_fail=1
        fi
    done < "${TMP_CLIENTMETA}"
    if [ "$_cm_fail" = "0" ]; then
        info -c vlan "save_settings.sh: ClientMeta keys applied"
    fi
fi

rm -f "${TMP_OVERRIDE}" "${TMP_CLIENTMETA}" "${TMP_NORMAL}"

chmod 600 "${SETTINGS_FILE}"
info -c vlan "save_settings.sh: updated ${SETTINGS_FILE}"

# ============================================================================ #
# STEP 4: Convert to pretty JSON format                                        #
# Build a properly formatted JSON object from sorted key-value pairs. Escape   #
# special characters (backslashes, quotes) and add comma separators between    #
# entries. The last entry has no trailing comma (valid JSON).                  #
# If the settings file is structured, preserve that structure in the public    #
# JSON by copying the updated settings.json instead of flattening.             #
# ============================================================================ #

if grep -q '"General"[[:space:]]*:' "${SETTINGS_FILE}" 2>/dev/null || \
   grep -q '"Hardware"[[:space:]]*:' "${SETTINGS_FILE}" 2>/dev/null; then
    cp "${SETTINGS_FILE}" "${TMP_JSON}"
else
    echo "{" > "${TMP_JSON}"

    # Count total lines to know when we've reached the last entry (no trailing comma)
    LINECOUNT=$(wc -l < "${TMP_SORTED}")
    COUNT=0

    _save_tab=$(printf '\t')
    while IFS="$_save_tab" read -r OUTKEY OUTVAL; do
        COUNT=$((COUNT + 1))

        # Escape backslashes and quotes in value to make valid JSON string literals
        ESCAPED_VAL=$(json_escape_string "${OUTVAL}")

        # Add comma after entries except the last one (valid JSON format)
        if [ "${COUNT}" -lt "${LINECOUNT}" ]; then
            printf '  "%s": "%s",\n' "${OUTKEY}" "${ESCAPED_VAL}" >> "${TMP_JSON}"
        else
            printf '  "%s": "%s"\n' "${OUTKEY}" "${ESCAPED_VAL}" >> "${TMP_JSON}"
        fi
    done < "${TMP_SORTED}"

    # Close JSON object
    echo "}" >> "${TMP_JSON}"
fi

# ============================================================================ #
# ============================================================================ #
# STEP 5: Install public (UI-fetchable) copy                                   #
# Copy the JSON to the web-accessible public directory so the iframe can       #
# fetch settings/settings.json. World-readable (644) permissions allow the UI  #
# to load settings without special access. Warns if the public dir is missing  #
# ============================================================================ #

if [ -n "${PUBLIC_MERV_BASE}" ]; then
    # Attempt to create the public settings directory for web access
    if mkdir -p "${PUBLIC_SETTINGS_DIR}" 2>/dev/null; then
        # PUBLIC_SETTINGS_FILE is a symlink to SETTINGS_FILE (created by install.sh).
        # cp follows symlinks on the destination, so this write goes to the same
        # JFFS file already updated in step 3. It is a harmless idempotent sync
        # that also handles the fallback case where the symlink was replaced by a
        # regular file (e.g. by a cp from an older install.sh version).
        cp "${TMP_JSON}" "${PUBLIC_SETTINGS_FILE}"
        # Set world-readable permissions so the web UI can access it
        chmod 644 "${PUBLIC_SETTINGS_FILE}"
        info -c vlan,cli "Settings saved!"
    else
        # Directory creation failed; warn but don't abort (persistent copy already installed)
        warn -c vlan "save_settings.sh: WARN can't mkdir ${PUBLIC_SETTINGS_DIR}"
    fi
else
    # No public base directory configured; persistent copy installed but web UI won't see it
    error -c vlan "save_settings.sh: WARN no public base dir available, skipping web copy"
fi

# ============================================================================ #
# CLEANUP                                                                      #
# Remove all temporary files used during the conversion process. These files   #
# contain intermediate key-value and JSON data and are no longer needed after  #
# the persistent and public copies have been installed successfully.           #
# ============================================================================ #

# Delete temporary work files (no longer needed after installation)
rm -f "${TMP_KV}" "${TMP_SORTED}" "${TMP_JSON}"

# Signal successful completion to parent script
exit 0
