#!/bin/sh
# Bounded, non-mutating Dropbear first-contact probe.
#
# This is the only production path allowed to use one -y.  It runs in a fresh
# private HOME, requests -N (no remote command), waits only for Dropbear to
# publish the host key, then terminates the client before authentication can
# start a remote action.  The displayed fingerprint and the exact captured
# known-host key must match before the canonical tuple is returned.

: "${MERV_BASE:=/jffs/addons/mervlan}"
[ -n "${VAR_SETTINGS_LOADED:-}" ] || . "$MERV_BASE/settings/var_settings.sh" || exit 2
[ -n "${LIB_JSON_LOADED:-}" ] || . "$MERV_BASE/settings/lib_json.sh" || exit 2
[ -n "${LIB_SSH_TRUST_LOADED:-}" ] || . "$MERV_BASE/settings/lib_ssh_trust.sh" || exit 2

_shkp_node="${1:-}"
_shkp_host=$(merv_ssh_trust_normalize_host "${2:-}") || exit 2
_shkp_port=$(merv_ssh_trust_normalize_port "${3:-}") || exit 2
printf '%s\n' "$_shkp_node" | grep -Eq '^NODE[1-9][0-9]*@[A-Za-z0-9.:-]+$' || exit 2
# The node ID may be MAC-based or endpoint-based.  The parent worker already
# derived and validated it; this adapter only preserves that identity and never
# substitutes a browser- or probe-supplied node key.

_shkp_user=$(json_get_flag NODE_SSH_USER "__MISSING__" "$SETTINGS_FILE" 2>/dev/null)
[ "$_shkp_user" = "__MISSING__" ] || [ -n "$_shkp_user" ] || _shkp_user=""
[ -n "$_shkp_user" ] || _shkp_user=$(json_get_flag SSH_USER admin "$SETTINGS_FILE" 2>/dev/null)
[ -n "$_shkp_user" ] || _shkp_user=admin
case "$_shkp_user" in *[!A-Za-z0-9._-]*) exit 2 ;; esac
[ -f "${SSH_KEY:-}" ] || exit 3

_shkp_client="${MERV_SSH_CLIENT:-dbclient}"
case "$_shkp_client" in *[!A-Za-z0-9_./-]*) exit 2 ;; esac
if merv_has merv_cmd; then
  _shkp_client_path=$(merv_cmd "$_shkp_client" 2>/dev/null) || exit 3
else
  _shkp_client_path="$_shkp_client"
  [ -x "$_shkp_client_path" ] || exit 3
fi

_shkp_root="${TMPDIR:-/tmp/mervlan_tmp}/ssh_hostkey_probe.$$"
case "$_shkp_root" in /tmp/mervlan_tmp/ssh_hostkey_probe.[0-9]*) ;; *) exit 2 ;; esac
mkdir -p "$_shkp_root/.ssh" 2>/dev/null || exit 4
chmod 700 "$_shkp_root" "$_shkp_root/.ssh" 2>/dev/null || exit 4
_shkp_pid=""
_shkp_cleanup() {
  if [ -n "${_shkp_pid:-}" ] && kill -0 "$_shkp_pid" 2>/dev/null; then
    kill "$_shkp_pid" 2>/dev/null || :
    sleep 1
    kill -9 "$_shkp_pid" 2>/dev/null || :
  fi
  [ -n "${_shkp_pid:-}" ] && wait "$_shkp_pid" 2>/dev/null || :
  rm -f "$_shkp_root/.ssh/known_hosts" "$_shkp_root/client.stdout" "$_shkp_root/client.stderr" 2>/dev/null || :
  rmdir "$_shkp_root/.ssh" "$_shkp_root" 2>/dev/null || :
}
trap '_shkp_cleanup' EXIT INT TERM

_shkp_home="$_shkp_root"
export HOME="$_shkp_home"
"$_shkp_client_path" -y -N -p "$_shkp_port" -i "$SSH_KEY" \
  "$_shkp_user@$_shkp_host" >"$_shkp_root/client.stdout" 2>"$_shkp_root/client.stderr" &
_shkp_pid=$!
_shkp_wait="${MERV_SSH_CONNECT_TIMEOUT:-10}"
case "$_shkp_wait" in ''|*[!0-9]*) _shkp_wait=10 ;; esac
[ "$_shkp_wait" -ge 1 ] 2>/dev/null || _shkp_wait=10
_shkp_tick=0
while [ "$_shkp_tick" -lt "$_shkp_wait" ]; do
  [ -s "$_shkp_root/.ssh/known_hosts" ] && break
  kill -0 "$_shkp_pid" 2>/dev/null || break
  sleep 1
  _shkp_tick=$((_shkp_tick + 1))
done
[ -s "$_shkp_root/.ssh/known_hosts" ] || exit 5

_shkp_host_token="$_shkp_host"
[ "$_shkp_port" = 22 ] || _shkp_host_token="[$_shkp_host]:$_shkp_port"
_shkp_count=$(awk -v h="$_shkp_host_token" '$1==h {n++} END {print n+0}' "$_shkp_root/.ssh/known_hosts" 2>/dev/null)
[ "$_shkp_count" = 1 ] || exit 5
_shkp_record=$(awk -v h="$_shkp_host_token" '$1==h {print $2 "\t" $3; exit}' "$_shkp_root/.ssh/known_hosts" 2>/dev/null) || exit 5
_shkp_algorithm=$(printf '%s\n' "$_shkp_record" | awk -F '\t' '{print $1}')
_shkp_key=$(printf '%s\n' "$_shkp_record" | awk -F '\t' '{print $2}')
merv_ssh_trust_algorithm_valid "$_shkp_algorithm" || exit 5
merv_ssh_trust_key_valid "$_shkp_key" || exit 5
_shkp_display=$(awk '{for (i=1; i<=NF; i++) if (substr($i,1,7)=="SHA256:") {print $i; exit}}' "$_shkp_root/client.stderr" 2>/dev/null)
merv_ssh_trust_fingerprint_valid "$_shkp_display" || exit 5
_shkp_derived=$(merv_ssh_trust_derive_fingerprint "$_shkp_algorithm" "$_shkp_key" 2>/dev/null) || exit 5
[ "$_shkp_display" = "$_shkp_derived" ] || exit 5

printf '%s\t%s\t%s\n' "$_shkp_algorithm" "$_shkp_key" "$_shkp_display"
exit 0
